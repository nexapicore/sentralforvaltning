# Sentral Forvaltning — Investor Readiness Program

Production-ready Next.js (App Router) app for Sentral Forvaltning AS — a Norwegian founder-side strategic preparation service. Provides a guided readiness flow, AI-generated diagnosis, Stripe checkout for paid services, Supabase-backed storage of submissions and decks, and Resend-powered transactional emails.

## Stack

- **Next.js 15** (App Router, Server Components, React 19)
- **Supabase** — Postgres + private file storage
- **Stripe Checkout** — payments (NOK)
- **Anthropic Claude** — AI enrichment of diagnosis
- **Resend** — transactional email
- **Zod** — input validation

## Legal positioning (non-negotiable)

This app is positioned strictly as **founder-side strategic preparation**. It is NOT:
- investment advice (`investeringsråd`)
- valuation (`verdivurdering`)
- securities brokerage (`verdipapirformidling`)
- crowdfunding (`folkefinansiering`)
- an investor marketplace

Every customer-facing surface includes a Norwegian-language disclaimer pinned to `LEGAL_DISCLAIMER_VERSION`. Consent timestamp and disclaimer version are stored with every submission.

## Project structure

```
sentral-forvaltning/
├── app/
│   ├── api/
│   │   ├── submissions/route.ts      POST: persist readiness submission + consent
│   │   ├── upload/route.ts           POST: secure file upload to private bucket
│   │   ├── diagnosis/route.ts        POST: generate AI diagnosis, email user
│   │   ├── checkout/route.ts         POST: create Stripe Checkout Session
│   │   ├── webhook/route.ts          POST: Stripe webhook handler
│   │   └── notify/route.ts           POST: admin re-send internal notification
│   ├── diagnosis/[submission_id]/    Dynamic diagnosis result page
│   ├── flow/                         Guided 7-step readiness flow
│   ├── services/                     Paid service catalog
│   ├── faq/, dataroom/, success/
│   ├── layout.tsx, page.tsx, globals.css
├── components/
│   ├── landing/                      Hero, ThreeSteps, ExamplePreview, FinalCTA, modal
│   ├── flow/                         FlowController, ProgressBar, FileUpload, ConsentBox, LoadingScreen
│   ├── diagnosis/                    ScoreRing, CoveragePills, UpsellCard, SelfServeSection, DiagnosisView
│   ├── services/                     ServiceCard, ServiceSmall
│   └── shared/                       Nav, Footer, TrustBox
├── lib/
│   ├── env.ts                        Zod-validated env loader
│   ├── supabase.ts                   Admin (service role, server-only) + public clients
│   ├── stripe.ts                     Stripe singleton
│   ├── products.ts                   Canonical product catalog (server-side price source)
│   ├── diagnosis.ts                  Heuristic scoring + Claude enrichment
│   ├── email.ts                      Resend wrappers
│   ├── validators.ts                 Zod schemas for all API inputs
│   ├── rate-limit.ts                 Per-IP token bucket
│   └── constants.ts                  Client-safe constants (copy strings, public catalog)
├── emails/                           HTML email render functions
├── supabase/migrations/              Database schema with RLS policies
├── types/                            Shared TypeScript types
├── .env.example
├── next.config.mjs
├── package.json
└── tsconfig.json
```

## Setup

### 1. Install dependencies

```bash
npm install
```

### 2. Create a Supabase project

1. Go to [supabase.com](https://supabase.com) and create a new project.
2. In the SQL editor, run `supabase/migrations/0001_initial_schema.sql`.
3. Verify the `decks` storage bucket exists and is **private** (no public read policy).
4. From Project Settings → API, copy:
   - `Project URL` → `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public` key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role` key → `SUPABASE_SERVICE_ROLE_KEY` (server-only)

### 3. Set up Stripe

1. Create a Stripe account and enable NOK currency.
2. From Developers → API keys, copy the secret key → `STRIPE_SECRET_KEY`.
3. From Developers → Webhooks, add an endpoint:
   - URL: `https://your-domain.com/api/webhook`
   - Events: `checkout.session.completed`, `checkout.session.expired`, `charge.refunded`
4. Copy the signing secret → `STRIPE_WEBHOOK_SECRET`.
5. In Tax settings, enable Norwegian VAT (MVA) if you want Stripe to handle tax.

### 4. Set up Anthropic Claude

1. Create an API key at [console.anthropic.com](https://console.anthropic.com) → `ANTHROPIC_API_KEY`.
2. The app uses `claude-sonnet-4-5` by default. Update `lib/diagnosis.ts` if needed.

### 5. Set up Resend

1. Create a Resend account and verify your sending domain.
2. Copy API key → `RESEND_API_KEY`.
3. Set `FROM_EMAIL` to a verified sender like `Sentral Forvaltning <noreply@sentralforvaltning.no>`.
4. Set `INTERNAL_NOTIFICATION_EMAIL` to where you want order alerts to go.

### 6. Configure environment variables

Copy `.env.example` to `.env.local` and fill in real values:

```bash
cp .env.example .env.local
```

**Never commit `.env.local`.** All server-only secrets (service role, Stripe secret, Anthropic, Resend) must remain server-side.

### 7. Run locally

```bash
npm run dev
```

For local Stripe webhook testing, use the Stripe CLI:

```bash
stripe listen --forward-to localhost:3000/api/webhook
```

It will print a `whsec_…` secret. Put this in your local `STRIPE_WEBHOOK_SECRET`.

### 8. Deploy to Vercel

1. Push to GitHub and import in Vercel.
2. Add all env vars from `.env.example` in Project Settings → Environment Variables.
3. Set `NEXT_PUBLIC_SITE_URL` to the production URL.
4. Update the Stripe webhook URL to point at the production deploy.
5. Update Supabase Allowed URLs if needed.

## Security checklist

- ✅ Service role key is server-only — `lib/supabase.ts` throws if called from the browser
- ✅ Stripe secret key is server-only — same enforcement in `lib/stripe.ts`
- ✅ Anthropic and Resend keys are server-only via `lib/env.ts`
- ✅ Stripe webhook signature is verified using the raw request body before processing
- ✅ File uploads validated server-side for MIME type, size, and stored in a private bucket
- ✅ RLS enabled on all tables with no public policies — all reads go through the admin client server-side
- ✅ Per-IP rate limiting on submission, upload, diagnosis, and checkout endpoints
- ✅ Price never trusted from client — checkout resolves price from the server-side product catalog
- ✅ Consent timestamp, IP hash (not raw IP), and legal disclaimer version pinned to every submission

## Database schema

Three tables (all with RLS, no public policies):

- **submissions** — every form submission with consent audit trail and diagnosis result
- **orders** — Stripe checkout sessions, transitioned `pending` → `paid` → `fulfilled` via webhook
- **events** — webhook idempotency log

Storage:
- **decks** bucket — private, 25 MB limit, PDF/PPT/PPTX only

## Operational notes

- Diagnosis generation is idempotent — calling `/api/diagnosis` twice returns the existing result.
- The webhook handler is idempotent via the `events.stripe_event_id` unique constraint.
- Email failures don't block API responses — they're fire-and-forget and logged.
- If Claude API fails, diagnosis falls back to deterministic heuristics so the user always gets a result.

## Updating the legal disclaimer

When the legal disclaimer changes:

1. Update text in `lib/constants.ts` (`LEGAL_DISCLAIMER_FULL`, `LEGAL_DISCLAIMER_SHORT`, `CONSENT_TEXT`).
2. Bump `LEGAL_DISCLAIMER_VERSION` env var (e.g. `2026.02`).
3. New submissions and orders will be stamped with the new version. Existing rows retain their original version for audit purposes.

## Updating prices

Prices are defined in two places that must match:

1. `lib/products.ts` — **server-side source of truth** (used for checkout)
2. `lib/constants.ts` — UI display only

Always update server-side first. The UI value is purely cosmetic; if a client tampers with it, the server still charges the correct amount because checkout always resolves price from `lib/products.ts`.
