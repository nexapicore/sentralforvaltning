// Shared domain types

export type ProductId =
  | 'pitch-deck-review'
  | 'financial-model-review'
  | 'full-readiness'
  | 'readiness-package'
  | 'cap-table'
  | 'capital-structure'
  | 'narrative-review';

export interface Product {
  id: ProductId;
  name: string;
  price_nok: number;
  description: string;
  deliverable: string;
}

export type ConfidenceClass = 'high' | 'medium' | 'low';
export type CoverageState = 'covered' | 'partial' | 'missing';
export type DiagnosisStatus = 'pending' | 'processing' | 'completed' | 'failed';
export type OrderStatus = 'pending' | 'paid' | 'fulfilled' | 'failed' | 'refunded' | 'cancelled';

export interface CoverageCategory {
  name: string;
  state: CoverageState;
}

export interface Submission {
  id: string;
  created_at: string;

  company_name: string;
  sector: string;
  stage: string;
  website: string | null;

  email: string;
  contact_name: string | null;

  preparing_for: string | null;
  has_materials: string[];
  uncertainty: string | null;

  deck_storage_path: string | null;
  deck_filename: string | null;
  deck_size_bytes: number | null;
  deck_mime_type: string | null;

  score: number | null;
  badge: string | null;
  confidence_level: string | null;
  confidence_class: ConfidenceClass | null;
  strengths: string[];
  gaps: string[];
  coverage: CoverageCategory[];
  recommended_product_id: ProductId | null;
  recommended_product_name: string | null;
  recommended_product_price_nok: number | null;

  consent_given: boolean;
  consent_timestamp: string | null;
  legal_disclaimer_version: string;

  diagnosis_status: DiagnosisStatus;
}

export interface Order {
  id: string;
  submission_id: string | null;
  product_id: ProductId;
  product_name: string;
  amount_nok: number;
  customer_email: string;
  customer_name: string | null;
  stripe_session_id: string | null;
  stripe_payment_intent_id: string | null;
  status: OrderStatus;
  paid_at: string | null;
  legal_disclaimer_version: string;
  deliverable_description: string;
}

export interface SubmissionInput {
  company_name: string;
  sector: string;
  stage: string;
  website?: string;
  email: string;
  contact_name?: string;
  preparing_for?: string;
  has_materials: string[];
  uncertainty?: string;
  deck_storage_path?: string;
  deck_filename?: string;
  deck_size_bytes?: number;
  deck_mime_type?: string;
  consent_given: boolean;
}
