'use client';

import { useState } from 'react';

interface Props {
  id: string;
  category: string;
  name: string;
  description: string;
  price_nok: number;
  featured?: boolean;
}

export function ServiceCard({ id, category, name, description, price_nok, featured }: Props) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function checkout() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ product_id: id })
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.error || 'Checkout-feil');
      }
      const { url } = (await res.json()) as { url: string };
      window.location.href = url;
    } catch (err) {
      setLoading(false);
      setError(err instanceof Error ? err.message : 'Noe gikk galt');
    }
  }

  return (
    <div className={`service-card${featured ? ' featured' : ''}`}>
      <div className="service-cat">{category}</div>
      <h3 className="service-name">{name}</h3>
      <p className="service-desc">{description}</p>
      <div className="service-meta">
        <div>
          <div className="service-price">NOK {price_nok.toLocaleString('no-NO')}</div>
          <div className="service-price-note">eks. MVA</div>
        </div>
        <div className="service-price-note">Levering 24t</div>
      </div>
      <button type="button" className="service-cta" onClick={checkout} disabled={loading}>
        {loading ? 'Åpner checkout…' : 'Bestill'}
      </button>
      {error && (
        <div className="field-error visible" style={{ marginTop: 8 }}>
          {error}
        </div>
      )}
    </div>
  );
}
