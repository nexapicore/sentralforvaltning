'use client';

import { useState } from 'react';

interface Props {
  id: string;
  name: string;
  price_nok: number;
}

export function ServiceSmall({ id, name, price_nok }: Props) {
  const [loading, setLoading] = useState(false);

  async function checkout() {
    setLoading(true);
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ product_id: id })
      });
      if (!res.ok) throw new Error('Checkout error');
      const { url } = (await res.json()) as { url: string };
      window.location.href = url;
    } catch {
      setLoading(false);
    }
  }

  return (
    <button
      type="button"
      className="service-small"
      onClick={checkout}
      disabled={loading}
      style={{ textAlign: 'left', width: '100%', border: '1px solid var(--border-soft)' }}
    >
      <div className="service-small-name">{name}</div>
      <div className="service-small-price">NOK {price_nok.toLocaleString('no-NO')}</div>
    </button>
  );
}
