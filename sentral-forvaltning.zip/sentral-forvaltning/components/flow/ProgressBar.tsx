interface Props {
  current: number;
  total: number;
}

export function ProgressBar({ current, total }: Props) {
  return (
    <div className="progress-bar">
      {Array.from({ length: total }, (_, i) => {
        const n = i + 1;
        const cls = n < current ? 'progress-dot done' : n === current ? 'progress-dot active' : 'progress-dot';
        return <div key={n} className={cls} />;
      })}
    </div>
  );
}
