'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { ProgressBar } from './ProgressBar';
import { SingleSelect, MultiSelect } from './OptionGrid';
import { FileUpload, UploadedFile } from './FileUpload';
import { ConsentBox } from './ConsentBox';
import { LoadingScreen } from './LoadingScreen';
import {
  SECTORS,
  STAGES,
  PREPARING_FOR_OPTIONS,
  MATERIALS_OPTIONS,
  UNCERTAINTY_OPTIONS
} from '@/lib/constants';

const TOTAL = 7;

interface FormState {
  company_name: string;
  sector: string;
  stage: string;
  website: string;
  preparing_for: string;
  has_materials: string[];
  uncertainty: string;
  email: string;
  contact_name: string;
  consent: boolean;
  uploaded: UploadedFile | null;
}

const STEP_LABELS = [
  '',
  'Steg 1 av 7 — Velkommen',
  'Steg 2 av 7 — Selskap',
  'Steg 3 av 7 — Materiale',
  'Steg 4 av 7 — Kapitalprosess',
  'Steg 5 av 7 — Eksisterende',
  'Steg 6 av 7 — Usikkerhet',
  'Steg 7 av 7 — Bekreft'
];
const STEP_TITLES = [
  '',
  'La oss kartlegge selskapets readiness',
  'Fortell oss om selskapet',
  'Last opp materiale',
  'Hva forbereder selskapet seg på?',
  'Hva har dere allerede?',
  'Hva er største usikkerhet akkurat nå?',
  'Generer din diagnose'
];
const STEP_SUBS = [
  '',
  'Du trenger ikke vite hvor du skal starte. Vi finner riktig neste steg basert på materialet og svarene dine.',
  'Grunnleggende informasjon for å sette kontekst.',
  'Opplastet materiale gir mer presis diagnose, men er valgfritt.',
  'Velg det som best beskriver hvor dere er.',
  'Velg alle som passer.',
  'Velg det som brenner mest.',
  'Vi sender diagnose-rapporten direkte på e-post.'
];

export function FlowController() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);

  const [form, setForm] = useState<FormState>({
    company_name: '',
    sector: '',
    stage: '',
    website: '',
    preparing_for: '',
    has_materials: [],
    uncertainty: '',
    email: '',
    contact_name: '',
    consent: false,
    uploaded: null
  });

  const [errors, setErrors] = useState<Record<string, boolean>>({});

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm(f => ({ ...f, [key]: value }));
    if (errors[key]) setErrors(e => ({ ...e, [key]: false }));
  }

  function validateStep2(): boolean {
    const e: Record<string, boolean> = {};
    if (!form.company_name.trim()) e.company_name = true;
    if (!form.sector) e.sector = true;
    if (!form.stage) e.stage = true;
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function next() {
    if (step === 2 && !validateStep2()) return;
    setStep(s => Math.min(s + 1, TOTAL));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function back() {
    setStep(s => Math.max(s - 1, 1));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function isValidEmail(v: string): boolean {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
  }

  async function submit() {
    const e: Record<string, boolean> = {};
    if (!form.email || !isValidEmail(form.email)) e.email = true;
    if (!form.consent) e.consent = true;
    setErrors(e);
    if (Object.keys(e).length > 0) return;

    setSubmitting(true);
    setServerError(null);

    try {
      const payload = {
        company_name: form.company_name.trim(),
        sector: form.sector,
        stage: form.stage,
        website: form.website.trim() || undefined,
        email: form.email.trim(),
        contact_name: form.contact_name.trim() || undefined,
        preparing_for: form.preparing_for || undefined,
        has_materials: form.has_materials,
        uncertainty: form.uncertainty || undefined,
        deck_storage_path: form.uploaded?.storage_path,
        deck_filename: form.uploaded?.filename,
        deck_size_bytes: form.uploaded?.size_bytes,
        deck_mime_type: form.uploaded?.mime_type,
        consent_given: true
      };

      const subRes = await fetch('/api/submissions', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!subRes.ok) {
        const j = await subRes.json().catch(() => ({}));
        throw new Error(j.error || 'Kunne ikke lagre innsendingen');
      }
      const { submission_id } = (await subRes.json()) as { submission_id: string };

      // Kick off diagnosis generation. This happens server-side.
      const diagRes = await fetch('/api/diagnosis', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ submission_id })
      });
      if (!diagRes.ok) {
        // Diagnosis row exists but generation failed — still navigate so the user
        // sees an error on the diagnosis page rather than a blank screen.
        router.push(`/diagnosis/${submission_id}?error=1`);
        return;
      }

      router.push(`/diagnosis/${submission_id}`);
    } catch (err) {
      setSubmitting(false);
      setServerError(err instanceof Error ? err.message : 'Noe gikk galt');
    }
  }

  if (submitting) return <LoadingScreen />;

  return (
    <div className="container-form">
      <div className="flow-wrap">
        <div className="flow-header">
          <ProgressBar current={step} total={TOTAL} />
          <div className="flow-step-label">{STEP_LABELS[step]}</div>
          <h2 className="flow-title">{STEP_TITLES[step]}</h2>
          <p className="flow-sub">{STEP_SUBS[step]}</p>
        </div>

        <div className="flow-body">
          {step === 1 && (
            <div style={{ padding: '12px 0' }}>
              <p style={{ fontSize: 14, color: 'var(--ink-soft)', marginBottom: 16, lineHeight: 1.65 }}>
                Denne gjennomgangen tar 5–7 minutter. Vi spør om:
              </p>
              <ul style={{ listStyle: 'none', marginLeft: 4 }}>
                {[
                  'Grunnleggende selskaps-informasjon',
                  'Pitch deck (valgfritt å laste opp)',
                  'Kapitalprosess du forbereder',
                  'Eksisterende materiell og største usikkerhet'
                ].map(t => (
                  <li
                    key={t}
                    style={{ padding: '8px 0 8px 28px', fontSize: 14, color: 'var(--ink-soft)', position: 'relative' }}
                  >
                    <span style={{ position: 'absolute', left: 0, color: 'var(--accent)', fontWeight: 500 }}>→</span>
                    {t}
                  </li>
                ))}
              </ul>
              <div className="flow-nav" style={{ marginTop: 24 }}>
                <button type="button" className="btn-back" onClick={() => router.push('/')}>
                  ← Avbryt
                </button>
                <button type="button" className="btn-next" onClick={next}>
                  Start →
                </button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div>
              <div className="field-group">
                <label>
                  Selskapsnavn <span className="required">*</span>
                </label>
                <input
                  type="text"
                  className={errors.company_name ? 'error' : ''}
                  value={form.company_name}
                  onChange={e => update('company_name', e.target.value)}
                  placeholder="Bedrift AS"
                  autoComplete="organization"
                />
                {errors.company_name && <div className="field-error visible">Selskapsnavn er påkrevd</div>}
              </div>

              <div className="field-row">
                <div className="field-group">
                  <label>
                    Sektor <span className="required">*</span>
                  </label>
                  <select
                    className={errors.sector ? 'error' : ''}
                    value={form.sector}
                    onChange={e => update('sector', e.target.value)}
                  >
                    <option value="">Velg sektor</option>
                    {SECTORS.map(s => (
                      <option key={s}>{s}</option>
                    ))}
                  </select>
                  {errors.sector && <div className="field-error visible">Velg sektor</div>}
                </div>
                <div className="field-group">
                  <label>
                    Fase <span className="required">*</span>
                  </label>
                  <select
                    className={errors.stage ? 'error' : ''}
                    value={form.stage}
                    onChange={e => update('stage', e.target.value)}
                  >
                    <option value="">Velg fase</option>
                    {STAGES.map(s => (
                      <option key={s}>{s}</option>
                    ))}
                  </select>
                  {errors.stage && <div className="field-error visible">Velg fase</div>}
                </div>
              </div>

              <div className="field-group">
                <label>
                  Nettside <span className="opt">valgfritt</span>
                </label>
                <input
                  type="text"
                  value={form.website}
                  onChange={e => update('website', e.target.value)}
                  placeholder="bedrift.no"
                />
              </div>

              <div className="flow-nav">
                <button type="button" className="btn-back" onClick={back}>
                  ← Tilbake
                </button>
                <button type="button" className="btn-next" onClick={next}>
                  Fortsett →
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div>
              <FileUpload file={form.uploaded} onChange={f => update('uploaded', f)} />
              <div className="flow-nav" style={{ marginTop: 24 }}>
                <button type="button" className="btn-back" onClick={back}>
                  ← Tilbake
                </button>
                <button type="button" className="btn-next" onClick={next}>
                  Fortsett →
                </button>
              </div>
            </div>
          )}

          {step === 4 && (
            <div>
              <SingleSelect
                options={PREPARING_FOR_OPTIONS}
                value={form.preparing_for || null}
                onChange={v => update('preparing_for', v)}
              />
              <div className="flow-nav" style={{ marginTop: 28 }}>
                <button type="button" className="btn-back" onClick={back}>
                  ← Tilbake
                </button>
                <button type="button" className="btn-next" onClick={next}>
                  Fortsett →
                </button>
              </div>
            </div>
          )}

          {step === 5 && (
            <div>
              <MultiSelect
                options={MATERIALS_OPTIONS}
                values={form.has_materials}
                onChange={v => update('has_materials', v)}
                wideLast
              />
              <div className="flow-nav" style={{ marginTop: 28 }}>
                <button type="button" className="btn-back" onClick={back}>
                  ← Tilbake
                </button>
                <button type="button" className="btn-next" onClick={next}>
                  Fortsett →
                </button>
              </div>
            </div>
          )}

          {step === 6 && (
            <div>
              <SingleSelect
                options={UNCERTAINTY_OPTIONS}
                value={form.uncertainty || null}
                onChange={v => update('uncertainty', v)}
              />
              <div className="flow-nav" style={{ marginTop: 28 }}>
                <button type="button" className="btn-back" onClick={back}>
                  ← Tilbake
                </button>
                <button type="button" className="btn-next" onClick={next}>
                  Fortsett →
                </button>
              </div>
            </div>
          )}

          {step === 7 && (
            <div>
              <div className="field-group">
                <label>
                  E-postadresse <span className="required">*</span>
                </label>
                <input
                  type="email"
                  className={errors.email ? 'error' : ''}
                  value={form.email}
                  onChange={e => update('email', e.target.value)}
                  placeholder="navn@selskap.no"
                  autoComplete="email"
                />
                {errors.email && <div className="field-error visible">Gyldig e-postadresse er påkrevd</div>}
              </div>
              <div className="field-group">
                <label>
                  Ditt navn <span className="opt">valgfritt</span>
                </label>
                <input
                  type="text"
                  value={form.contact_name}
                  onChange={e => update('contact_name', e.target.value)}
                  placeholder="Ola Nordmann"
                  autoComplete="name"
                />
              </div>

              <ConsentBox checked={form.consent} onChange={v => update('consent', v)} error={errors.consent} />

              {serverError && (
                <div className="field-error visible" style={{ marginBottom: 12 }}>
                  {serverError}
                </div>
              )}

              <div className="flow-nav">
                <button type="button" className="btn-back" onClick={back}>
                  ← Tilbake
                </button>
                <button type="button" className="btn-next" onClick={submit} disabled={submitting}>
                  Generer foreløpig diagnose →
                </button>
              </div>
            </div>
          )}
        </div>

        <p className="flow-disclaimer">Konfidensielt · GDPR-kompatibel · Du eier alle data</p>
      </div>
    </div>
  );
}
