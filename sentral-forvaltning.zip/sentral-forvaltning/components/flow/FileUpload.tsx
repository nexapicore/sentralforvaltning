'use client';

import { useRef, useState } from 'react';

export interface UploadedFile {
  storage_path: string;
  filename: string;
  size_bytes: number;
  mime_type: string;
}

interface Props {
  file: UploadedFile | null;
  onChange: (file: UploadedFile | null) => void;
}

const ALLOWED = ['.pdf', '.ppt', '.pptx'];
const MAX_BYTES = 25 * 1024 * 1024;

export function FileUpload({ file, onChange }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragover, setDragover] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleFile(f: File) {
    setError(null);
    const ext = '.' + (f.name.split('.').pop()?.toLowerCase() ?? '');
    if (!ALLOWED.includes(ext)) {
      setError('Ugyldig filtype. Bruk PDF, PPT eller PPTX.');
      return;
    }
    if (f.size > MAX_BYTES) {
      setError('Filen er for stor (maks 25 MB).');
      return;
    }

    setUploading(true);
    try {
      const fd = new FormData();
      fd.append('file', f);
      const res = await fetch('/api/upload', { method: 'POST', body: fd });
      if (!res.ok) {
        const j = await res.json().catch(() => ({ error: 'Opplastingsfeil' }));
        throw new Error(j.error || 'Opplastingsfeil');
      }
      const data = (await res.json()) as UploadedFile;
      onChange(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Opplastingsfeil');
    } finally {
      setUploading(false);
    }
  }

  function remove() {
    onChange(null);
    if (inputRef.current) inputRef.current.value = '';
  }

  const ext = file?.filename.split('.').pop()?.toUpperCase() ?? 'FIL';

  return (
    <>
      <label>
        Pitch deck eller investorpresentasjon <span className="opt">valgfritt, men anbefalt</span>
      </label>

      <div
        className={`upload-area${dragover ? ' dragover' : ''}${file ? ' has-file' : ''}${uploading ? ' uploading' : ''}`}
        onDragOver={e => {
          e.preventDefault();
          setDragover(true);
        }}
        onDragLeave={() => setDragover(false)}
        onDrop={e => {
          e.preventDefault();
          setDragover(false);
          const f = e.dataTransfer.files[0];
          if (f) handleFile(f);
        }}
      >
        <div className="upload-icon" aria-hidden>
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M10 13V3M10 3L6 7M10 3l4 4M3 13v3a2 2 0 002 2h10a2 2 0 002-2v-3" />
          </svg>
        </div>
        <div className="upload-title">{uploading ? 'Laster opp…' : 'Dra fil hit eller klikk for å velge'}</div>
        <div className="upload-sub">Pitch deck, investor memo eller investorpresentasjon</div>
        <div className="upload-formats">PDF · PPT · PPTX · Maks 25 MB</div>
        <input
          ref={inputRef}
          type="file"
          className="upload-input"
          accept=".pdf,.ppt,.pptx"
          aria-label="Last opp pitch deck"
          onChange={e => {
            const f = e.target.files?.[0];
            if (f) handleFile(f);
          }}
        />
      </div>

      {file && (
        <div className="file-chip" role="status">
          <div className="file-ext">{ext}</div>
          <div className="file-meta">
            <div className="file-nm">{file.filename}</div>
            <div className="file-sz">{formatSize(file.size_bytes)}</div>
          </div>
          <button type="button" className="file-x" onClick={remove}>
            Fjern
          </button>
        </div>
      )}

      {error && (
        <div className="field-error visible" style={{ marginTop: 10 }}>
          {error}
        </div>
      )}

      <p className="upload-helper">
        Du kan hoppe over dette, men opplastet materiale gir mer presis diagnose. Opplastet materiale behandles konfidensielt og brukes kun til readiness-diagnose og eventuelle bestilte leveranser.
      </p>
    </>
  );
}

function formatSize(b: number): string {
  if (b < 1024) return b + ' B';
  if (b < 1048576) return (b / 1024).toFixed(1) + ' KB';
  return (b / 1048576).toFixed(1) + ' MB';
}
