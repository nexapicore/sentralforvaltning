'use client';

interface SingleProps {
  options: readonly string[];
  value: string | null;
  onChange: (v: string) => void;
  wideLast?: boolean;
}

export function SingleSelect({ options, value, onChange, wideLast }: SingleProps) {
  return (
    <div className="option-grid">
      {options.map((opt, i) => {
        const wide = wideLast && i === options.length - 1 && options.length % 2 === 1;
        return (
          <button
            type="button"
            key={opt}
            className={`option-card${value === opt ? ' selected' : ''}${wide ? ' wide' : ''}`}
            onClick={() => onChange(opt)}
            aria-pressed={value === opt}
          >
            <span className="option-box" aria-hidden />
            <span>{opt}</span>
          </button>
        );
      })}
    </div>
  );
}

interface MultiProps {
  options: readonly string[];
  values: string[];
  onChange: (v: string[]) => void;
  wideLast?: boolean;
}

export function MultiSelect({ options, values, onChange, wideLast }: MultiProps) {
  function toggle(opt: string) {
    if (values.includes(opt)) onChange(values.filter(v => v !== opt));
    else onChange([...values, opt]);
  }
  return (
    <div className="option-grid">
      {options.map((opt, i) => {
        const wide = wideLast && i === options.length - 1 && options.length % 2 === 1;
        const selected = values.includes(opt);
        return (
          <button
            type="button"
            key={opt}
            className={`option-card${selected ? ' selected' : ''}${wide ? ' wide' : ''}`}
            onClick={() => toggle(opt)}
            aria-pressed={selected}
          >
            <span className="option-box" aria-hidden />
            <span>{opt}</span>
          </button>
        );
      })}
    </div>
  );
}
