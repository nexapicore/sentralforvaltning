'use client';

import { CONSENT_TEXT } from '@/lib/constants';

interface Props {
  checked: boolean;
  onChange: (v: boolean) => void;
  error?: boolean;
}

export function ConsentBox({ checked, onChange, error }: Props) {
  return (
    <div className={`consent-box${error ? ' error' : ''}`}>
      <label className="consent-label">
        <input
          type="checkbox"
          className="consent-cb"
          checked={checked}
          onChange={e => onChange(e.target.checked)}
        />
        <span>{CONSENT_TEXT}</span>
      </label>
      {error && (
        <div className="field-error visible" style={{ marginLeft: 30, marginTop: 8 }}>
          Du må bekrefte for å fortsette
        </div>
      )}
    </div>
  );
}
