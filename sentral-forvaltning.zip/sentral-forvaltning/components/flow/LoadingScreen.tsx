'use client';

import { useEffect, useState } from 'react';

const STEPS = [
  'Leser opplastet materiale',
  'Mapper svar mot readiness-kategorier',
  'Identifiserer styrker og mangler',
  'Vurderer dokumentasjonsnivå',
  'Genererer anbefalt neste steg'
];

export function LoadingScreen() {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const timers: ReturnType<typeof setTimeout>[] = [];
    STEPS.forEach((_, i) => {
      timers.push(setTimeout(() => setActive(i + 1), i * 700 + 400));
    });
    return () => timers.forEach(clearTimeout);
  }, []);

  return (
    <div className="loading-wrap">
      <div className="loading-visual" aria-hidden>
        <div className="loading-ring" />
        <div className="loading-ring" />
        <div className="loading-ring" />
      </div>
      <h2 className="loading-title">Analyserer readiness</h2>
      <p className="loading-sub">Strukturerer materiale og svar</p>
      <div className="loading-steps">
        {STEPS.map((label, i) => {
          const idx = i + 1;
          const cls =
            idx < active ? 'loading-step done' : idx === active ? 'loading-step active' : 'loading-step';
          return (
            <div key={label} className={cls}>
              <span className="ls-mark" />
              {label}
            </div>
          );
        })}
      </div>
    </div>
  );
}
