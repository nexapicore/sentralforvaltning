import Link from 'next/link';

export function FinalCTA() {
  return (
    <div className="final-cta">
      <h2>Klar til å starte?</h2>
      <p>Gratis foreløpig diagnose. Ingen kredittkort.</p>
      <Link href="/flow" className="btn-primary">Start readiness-sjekk →</Link>
    </div>
  );
}
