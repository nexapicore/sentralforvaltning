const STEPS = [
  {
    n: 1,
    title: 'Last opp materiale',
    desc: 'Pitch deck eller investorpresentasjon. Du kan også starte uten opplasting.'
  },
  {
    n: 2,
    title: 'Svar på nøkkelspørsmål',
    desc: 'Vi kartlegger fase, kapitalprosess, eksisterende materiale og største usikkerhet.'
  },
  {
    n: 3,
    title: 'Få foreløpig diagnose',
    desc: 'Du får score, styrker, mangler, materialdekning og anbefalt neste steg.'
  }
];

export function ThreeSteps() {
  return (
    <div className="steps-section">
      <div className="steps-header">
        <div className="steps-eyebrow">Slik fungerer det</div>
        <h2 className="steps-title">Tre steg til klarhet</h2>
      </div>
      <div className="steps-grid">
        {STEPS.map(s => (
          <div key={s.n} className="step-card">
            <div className="step-num">{s.n}</div>
            <h3 className="step-title">{s.title}</h3>
            <p className="step-desc">{s.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
