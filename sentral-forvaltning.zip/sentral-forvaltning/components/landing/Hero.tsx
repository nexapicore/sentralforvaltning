'use client';

import Link from 'next/link';
import { useState } from 'react';
import { ExampleReportModal } from './ExampleReportModal';

export function Hero() {
  const [modalOpen, setModalOpen] = useState(false);
  return (
    <>
      <div className="hero">
        <div className="eyebrow">Investor Readiness Program</div>
        <h1>Forbered selskapet for kapital — steg for steg.</h1>
        <p className="hero-sub">
          Last opp pitch deck, svar på noen korte spørsmål, og få en foreløpig diagnose av styrker, mangler og anbefalt neste forberedelsessteg.
        </p>
        <div className="hero-ctas">
          <Link href="/flow" className="btn-primary">Start gratis readiness-sjekk →</Link>
          <button type="button" className="btn-secondary" onClick={() => setModalOpen(true)}>
            Se eksempelrapport
          </button>
        </div>
        <div className="hero-microcopy">Konfidensielt · 5–7 minutter · Ikke investeringsråd</div>
      </div>
      <ExampleReportModal open={modalOpen} onClose={() => setModalOpen(false)} />
    </>
  );
}
