const PREVIEW_PILLS = [
  { name: 'Team', state: 'covered' },
  { name: 'Marked', state: 'covered' },
  { name: 'Produkt', state: 'covered' },
  { name: 'Traksjon', state: 'partial' },
  { name: 'Forretningsmodell', state: 'partial' },
  { name: 'Finansiell modell', state: 'partial' },
  { name: 'Risikoanalyse', state: 'missing' },
  { name: 'Cap table', state: 'missing' },
  { name: 'Use of funds', state: 'partial' }
] as const;

export function ExamplePreview() {
  return (
    <div className="preview-section">
      <div className="steps-header">
        <div className="steps-eyebrow">Eksempel</div>
        <h2 className="steps-title">Slik ser diagnosen ut</h2>
      </div>
      <div className="preview-card">
        <div className="preview-watermark">EKSEMPEL</div>
        <div className="preview-header">
          <div>
            <div className="preview-badge">Sterke forberedelsessignaler</div>
            <div className="preview-co">Eksempel AS</div>
          </div>
          <div className="preview-score-block">
            <div className="preview-score">67</div>
            <div className="preview-score-sub">/ 100</div>
          </div>
        </div>
        <div
          style={{
            fontSize: 13,
            color: 'var(--muted)',
            fontWeight: 500,
            letterSpacing: '0.04em',
            textTransform: 'uppercase',
            marginBottom: 10
          }}
        >
          Materialdekning
        </div>
        <div className="preview-pills">
          {PREVIEW_PILLS.map(p => (
            <span key={p.name} className={`preview-pill ${p.state}`}>
              {p.name}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
