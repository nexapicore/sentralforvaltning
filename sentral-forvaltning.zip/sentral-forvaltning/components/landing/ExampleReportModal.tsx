'use client';

import Link from 'next/link';
import { useEffect } from 'react';

const SECTIONS = [
  { title: 'Sammendrag og samlet score', desc: 'Modenhets-indikasjon med kategori-klassifisering' },
  {
    title: 'Kategori-scorecard på 9 områder',
    desc: 'Team, marked, produkt, traksjon, modell, finansielt, narrativ, kapital, struktur'
  },
  { title: 'Topp 5 investor-vendte risikoer', desc: 'Hva en seriøs investor mest sannsynlig vil utfordre' },
  {
    title: 'Narrativ- og dokumentasjons-gjennomgang',
    desc: 'Konkrete forbedringer for pitch deck og investor memo'
  },
  { title: '30-dagers handlingsplan', desc: 'Uke-for-uke prioritering før investor-tilnærming' }
];

export function ExampleReportModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  useEffect(() => {
    if (open) {
      document.body.style.overflow = 'hidden';
      const handler = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
      window.addEventListener('keydown', handler);
      return () => {
        document.body.style.overflow = '';
        window.removeEventListener('keydown', handler);
      };
    }
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="modal-overlay visible"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Eksempelrapport"
    >
      <div className="modal-box" onClick={e => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose} aria-label="Lukk">×</button>

        <div
          style={{
            fontSize: 11,
            color: 'var(--accent)',
            fontWeight: 500,
            letterSpacing: '0.06em',
            textTransform: 'uppercase',
            marginBottom: 14
          }}
        >
          Eksempelrapport
        </div>
        <h2
          style={{
            fontFamily: 'Fraunces, serif',
            fontSize: 26,
            fontWeight: 500,
            color: 'var(--ink)',
            marginBottom: 8,
            letterSpacing: '-0.01em'
          }}
        >
          Slik leveres Full Investor Readiness Assessment
        </h2>
        <p style={{ fontSize: 14, color: 'var(--muted)', marginBottom: 24, lineHeight: 1.6 }}>
          Strukturert PDF-rapport på 8–12 sider, levert innen 24 timer. Skreddersydd til selskapet.
        </p>

        <div style={{ display: 'grid', gap: 14 }}>
          {SECTIONS.map(s => (
            <div
              key={s.title}
              style={{
                padding: '14px 16px',
                background: 'var(--card-warm)',
                borderRadius: 8,
                borderLeft: '3px solid var(--accent)'
              }}
            >
              <div style={{ fontWeight: 500, color: 'var(--ink)', marginBottom: 4, fontSize: 14 }}>{s.title}</div>
              <div style={{ fontSize: 13, color: 'var(--muted)' }}>{s.desc}</div>
            </div>
          ))}
        </div>

        <div style={{ marginTop: 28, display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          <Link href="/flow" className="btn-primary" onClick={onClose}>
            Start gratis sjekk først →
          </Link>
          <Link href="/services" className="btn-secondary" onClick={onClose}>
            Se tjenester
          </Link>
        </div>
      </div>
    </div>
  );
}
