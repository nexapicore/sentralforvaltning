import { CoverageCategory } from '@/types';

interface Props {
  coverage: CoverageCategory[];
}

export function CoveragePills({ coverage }: Props) {
  return (
    <div className="coverage-card">
      <div className="coverage-head">
        <div
          style={{
            fontSize: 12,
            fontWeight: 500,
            color: 'var(--muted)',
            letterSpacing: '0.04em',
            textTransform: 'uppercase'
          }}
        >
          Materialdekning
        </div>
        <div className="coverage-legend">
          <div className="legend-item">
            <span className="legend-dot covered" />Dekket
          </div>
          <div className="legend-item">
            <span className="legend-dot partial" />Delvis
          </div>
          <div className="legend-item">
            <span className="legend-dot missing" />Mangler
          </div>
        </div>
      </div>
      <div className="coverage-pills">
        {coverage.map(c => (
          <div key={c.name} className={`cov-pill ${c.state}`}>
            <span className="pdot" />
            {c.name}
          </div>
        ))}
      </div>
    </div>
  );
}
