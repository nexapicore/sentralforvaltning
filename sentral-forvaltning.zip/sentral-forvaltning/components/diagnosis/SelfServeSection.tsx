'use client';

import { useState } from 'react';

const CHECKLISTS = [
  {
    title: 'Pitch deck',
    items: [
      'Problem / solution-struktur',
      'Market og why now',
      'Traction og milestones',
      'Use of funds',
      'Team-slide'
    ]
  },
  {
    title: 'Financial readiness',
    items: [
      '24-måneders modell',
      'Burn og runway',
      'Antakelser dokumentert',
      'Sensitivitetsanalyse',
      'Unit economics'
    ]
  },
  {
    title: 'Data room',
    items: [
      'Selskapsdokumenter',
      'Cap table',
      'Aksjonæravtale',
      'Kundekontrakter',
      'GDPR-dokumentasjon'
    ]
  },
  {
    title: 'Investor narrative',
    items: ['One-liner', 'Why now-argument', 'Founder story', 'Risk response', 'Q&A-bank']
  }
];

export function SelfServeSection() {
  const [open, setOpen] = useState(false);
  const [checked, setChecked] = useState<Record<string, boolean>>({});

  function toggleItem(key: string) {
    setChecked(c => ({ ...c, [key]: !c[key] }));
  }

  return (
    <div className={`self-serve${open ? ' open' : ''}`}>
      <button type="button" className="self-serve-toggle" onClick={() => setOpen(o => !o)} aria-expanded={open}>
        <span className="self-serve-title">Vil du jobbe videre selv?</span>
        <span className="self-serve-icon" aria-hidden>
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M4 6l4 4 4-4" />
          </svg>
        </span>
      </button>
      <div className="self-serve-body">
        <div className="self-serve-inner">
          <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 20, lineHeight: 1.6 }}>
            Sjekklister du kan jobbe gjennom selv. Full ekspert-gjennomgang er fortsatt det raskeste neste steg.
          </p>

          <div className="checklist-grid">
            {CHECKLISTS.map(c => (
              <div key={c.title} className="checklist-card">
                <h4 className="checklist-card-h">{c.title}</h4>
                <ul className="checklist">
                  {c.items.map(item => {
                    const key = `${c.title}::${item}`;
                    return (
                      <li
                        key={item}
                        className={checked[key] ? 'checked' : ''}
                        onClick={() => toggleItem(key)}
                      >
                        <span className="cbox" />
                        <span>{item}</span>
                      </li>
                    );
                  })}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
