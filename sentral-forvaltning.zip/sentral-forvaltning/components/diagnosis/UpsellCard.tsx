'use client';

import { useState } from 'react';
import { ProductId } from '@/types';

interface Props {
  product_id: ProductId;
  product_name: string;
  product_price_nok: number;
  submission_id: string;
}

const DESCRIPTIONS: Record<string, string> = {
  'pitch-deck-review':
    'Strukturert gjennomgang av pitch deck, investor memo og støttemateriale. Identifiserer mangler før kapitalprosess, med konkret forbedringsplan.',
  'financial-model-review':
    'Gjennomgang av finansiell modell, antakelser, sensitivitet, runway, unit economics og kapitalbehov. Identifiserer hva investor mest sannsynlig vil utfordre.',
  'capital-structure':
    'Strategisk analyse av sannsynlig kapitalstruktur og indikative prisreferanser. Inkluderer utvanningsscenarier og anbefalt struktur. Ikke formell verdivurdering.',
  'full-readiness':
    'Strukturert advisory-gjennomgang på 9 forberedelseskategorier, levert som 8–12-siders PDF-rapport innen 24 timer.',
  'narrative-review':
    'Strukturert gjennomgang av narrativ, deck og kommunikasjons-materiell. Identifiserer hvordan selskapet best kan posisjoneres for investorer.',
  'readiness-package':
    'Komplett 90-dagers forberedelsesplan. Full vurdering, pitch deck-gjennomgang, cap table og uke-for-uke handlingsplan med revurdering etter 90 dager.',
  'cap-table':
    'Strukturanalyse av eierskap, opsjoner og konvertibler. Utvanningsmodellering og opprydding før emisjon.'
};

export function UpsellCard({ product_id, product_name, product_price_nok, submission_id }: Props) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function checkout() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ product_id, submission_id })
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.error || 'Checkout-feil');
      }
      const { url } = (await res.json()) as { url: string };
      window.location.href = url;
    } catch (err) {
      setLoading(false);
      setError(err instanceof Error ? err.message : 'Noe gikk galt');
    }
  }

  const desc = DESCRIPTIONS[product_id] ?? '';

  return (
    <div className="upsell">
      <div className="upsell-tag">ANBEFALT NESTE STEG</div>
      <h2 className="upsell-title">{product_name}</h2>
      <p className="upsell-desc">{desc}</p>
      <div className="upsell-row">
        <div>
          <div className="upsell-price">NOK {product_price_nok.toLocaleString('no-NO')}</div>
          <div className="upsell-price-note">eks. MVA · Levering innen 24 timer</div>
        </div>
        <button type="button" className="btn-primary" onClick={checkout} disabled={loading}>
          {loading ? 'Åpner checkout…' : 'Lås opp full rapport →'}
        </button>
      </div>
      {error && (
        <div className="field-error visible" style={{ marginTop: 12 }}>
          {error}
        </div>
      )}
    </div>
  );
}
