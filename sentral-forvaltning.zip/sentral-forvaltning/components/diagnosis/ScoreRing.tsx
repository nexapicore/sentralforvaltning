'use client';

import { useEffect, useRef, useState } from 'react';

interface Props {
  score: number;
}

const CIRCUMFERENCE = 502; // 2πr where r=80, rounded to match prototype

export function ScoreRing({ score }: Props) {
  const [displayed, setDisplayed] = useState(0);
  const ringRef = useRef<SVGCircleElement>(null);

  useEffect(() => {
    const t = setTimeout(() => {
      if (ringRef.current) {
        ringRef.current.style.strokeDashoffset = String(
          CIRCUMFERENCE - (score / 100) * CIRCUMFERENCE
        );
      }
      const start = performance.now();
      let raf = 0;
      function tick(t: number) {
        const p = Math.min((t - start) / 1800, 1);
        const eased = 1 - Math.pow(1 - p, 3);
        setDisplayed(Math.round(eased * score));
        if (p < 1) raf = requestAnimationFrame(tick);
      }
      raf = requestAnimationFrame(tick);
      return () => cancelAnimationFrame(raf);
    }, 150);
    return () => clearTimeout(t);
  }, [score]);

  return (
    <div className="score-ring-wrap" aria-label={`Score ${score} av 100`}>
      <svg className="score-svg" width="180" height="180" viewBox="0 0 180 180">
        <circle className="score-track" cx="90" cy="90" r="80" />
        <circle ref={ringRef} className="score-fill" cx="90" cy="90" r="80" />
      </svg>
      <div className="score-inner">
        <div className="score-n">{displayed}</div>
        <div className="score-denom">FORELØPIG</div>
      </div>
    </div>
  );
}
