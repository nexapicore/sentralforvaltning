import Link from 'next/link';
import { Submission, ProductId } from '@/types';
import { ScoreRing } from './ScoreRing';
import { CoveragePills } from './CoveragePills';
import { UpsellCard } from './UpsellCard';
import { SelfServeSection } from './SelfServeSection';

interface Props {
  submission: Submission;
}

export function DiagnosisView({ submission }: Props) {
  const score = submission.score ?? 0;
  const badge = submission.badge ?? 'Foreløpig diagnose';
  const confidenceClass = submission.confidence_class ?? 'medium';
  const confidenceLevel = submission.confidence_level ?? 'Middels';
  const strengths = submission.strengths ?? [];
  const gaps = submission.gaps ?? [];
  const coverage = submission.coverage ?? [];
  const productId = (submission.recommended_product_id ?? 'full-readiness') as ProductId;
  const productName = submission.recommended_product_name ?? 'Full Investor Readiness Assessment';
  const productPrice = submission.recommended_product_price_nok ?? 5000;

  return (
    <div className="container-narrow">
      <div className="diag-wrap">
        <div className="diag-top-note">
          Foreløpig diagnose · Basert på opplastet materiale og selvrapporterte svar · Ikke investeringsråd
        </div>

        <div className="diag-hero">
          <ScoreRing score={score} />
          <div className="diag-badge">{badge}</div>
          <h2 className="diag-co">{submission.company_name}</h2>
          <p className="diag-summary">
            Foreløpig diagnose for {submission.company_name} basert på{' '}
            {submission.deck_storage_path ? 'opplastet materiale og dine svar' : 'dine selvrapporterte svar'}.
            Resultatet utgjør ikke investeringsråd.
          </p>
          <div className={`conf-tag ${confidenceClass}`}>Konfidens: {confidenceLevel}</div>
        </div>

        <div className="diag-grid">
          <div className="diag-card">
            <div className="diag-card-h">Identifiserte styrker</div>
            {strengths.slice(0, 3).map((s, i) => (
              <div key={i} className="diag-item pos">{s}</div>
            ))}
            {strengths.length === 0 && <div className="diag-item">—</div>}
          </div>
          <div className="diag-card">
            <div className="diag-card-h">Identifiserte mangler</div>
            {gaps.slice(0, 3).map((g, i) => (
              <div key={i} className="diag-item neg">{g}</div>
            ))}
            {gaps.length === 0 && <div className="diag-item">—</div>}
          </div>
        </div>

        <CoveragePills coverage={coverage} />

        <UpsellCard
          product_id={productId}
          product_name={productName}
          product_price_nok={productPrice}
          submission_id={submission.id}
        />

        <div className="upsell-services-link">
          <Link href="/services" className="btn-link">
            Se alle tjenester
          </Link>
        </div>

        <SelfServeSection />

        <p
          style={{
            marginTop: 40,
            fontSize: 11,
            color: 'var(--faint)',
            textAlign: 'center',
            lineHeight: 1.7,
            maxWidth: 540,
            marginLeft: 'auto',
            marginRight: 'auto'
          }}
        >
          Foreløpig diagnose basert på opplastet materiale og selvrapporterte svar. Utgjør ikke investeringsråd, verdivurdering eller tilbudsdokument. Sentral Forvaltning AS er ikke et regulert verdipapirforetak.
        </p>
      </div>
    </div>
  );
}
