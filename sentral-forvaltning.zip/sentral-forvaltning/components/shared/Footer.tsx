import Link from 'next/link';
import { LEGAL_DISCLAIMER_FULL } from '@/lib/constants';

export function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div>
            <div className="footer-brand">Sentral <span>Forvaltning</span></div>
            <p className="footer-tagline">
              Strategisk forberedelse og forretningsmessig rådgivning for norske selskaper som vurderer kapitalinnhenting.
            </p>
          </div>
          <div className="footer-col">
            <h4>Tjenester</h4>
            <ul>
              <li><Link href="/services">Alle tjenester</Link></li>
              <li><Link href="/flow">Readiness-sjekk</Link></li>
              <li><Link href="/dataroom">Data Room</Link></li>
            </ul>
          </div>
          <div className="footer-col">
            <h4>Selskap</h4>
            <ul>
              <li>Om oss</li>
              <li>Kontakt</li>
              <li><Link href="/faq">FAQ</Link></li>
            </ul>
          </div>
          <div className="footer-col">
            <h4>Juridisk</h4>
            <ul>
              <li>Personvern</li>
              <li>Vilkår</li>
              <li>Ansvarsfraskrivelse</li>
            </ul>
          </div>
        </div>
        <div className="footer-legal">
          <strong>Sentral Forvaltning AS · Oslo, Norge</strong>
          <br />
          {LEGAL_DISCLAIMER_FULL} Selskapet er ikke et regulert verdipapirforetak i henhold til verdipapirhandelloven og er ikke autorisert som folkefinansieringstjenesteyter under forordning 2020/1503 (ECSP).
          <br /><br />© 2026 Sentral Forvaltning AS
        </div>
      </div>
    </footer>
  );
}
