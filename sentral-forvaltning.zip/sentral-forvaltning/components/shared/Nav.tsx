'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';

export function Nav() {
  const router = useRouter();
  return (
    <nav className="nav">
      <button
        type="button"
        className="nav-logo"
        onClick={() => router.push('/')}
        aria-label="Sentral Forvaltning"
      >
        Sentral <span>Forvaltning</span>
      </button>
      <div className="nav-menu">
        <Link href="/" className="nav-link">Hjem</Link>
        <Link href="/services" className="nav-link">Tjenester</Link>
        <Link href="/faq" className="nav-link">FAQ</Link>
        <Link href="/flow" className="nav-cta">Start</Link>
      </div>
    </nav>
  );
}
