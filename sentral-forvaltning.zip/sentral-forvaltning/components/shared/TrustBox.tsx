'use client';

import { useState } from 'react';
import { LEGAL_DISCLAIMER_SHORT, LEGAL_DISCLAIMER_FULL } from '@/lib/constants';

export function TrustBox() {
  const [open, setOpen] = useState(false);
  return (
    <div className="trust-box">
      <strong>Viktig avklaring</strong>
      {LEGAL_DISCLAIMER_SHORT}
      <button type="button" className="expand-link" onClick={() => setOpen(o => !o)}>
        {open ? 'Skjul' : 'Les mer'}
      </button>
      <div className={`trust-expanded ${open ? 'visible' : ''}`}>{LEGAL_DISCLAIMER_FULL}</div>
    </div>
  );
}
