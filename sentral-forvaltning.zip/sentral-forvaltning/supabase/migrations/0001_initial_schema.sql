-- ════════════════════════════════════════════════════════════
-- Sentral Forvaltning — Database Schema
-- All tables use RLS. Service role bypasses; anon has no read.
-- ════════════════════════════════════════════════════════════

create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";

-- ─── SUBMISSIONS ─────────────────────────────────────────────
-- Every readiness flow submission, stored verbatim with consent.
create table public.submissions (
  id uuid primary key default uuid_generate_v4(),
  created_at timestamptz not null default now(),

  -- Company
  company_name text not null,
  sector text not null,
  stage text not null,
  website text,

  -- Contact
  email text not null,
  contact_name text,

  -- Self-reported context
  preparing_for text,
  has_materials jsonb default '[]'::jsonb,
  uncertainty text,

  -- Uploaded file reference (path in private bucket)
  deck_storage_path text,
  deck_filename text,
  deck_size_bytes integer,
  deck_mime_type text,

  -- Computed diagnosis
  score integer,
  badge text,
  confidence_level text,
  confidence_class text,
  strengths jsonb default '[]'::jsonb,
  gaps jsonb default '[]'::jsonb,
  coverage jsonb default '[]'::jsonb,
  recommended_product_id text,
  recommended_product_name text,
  recommended_product_price_nok integer,

  -- Legal compliance audit trail
  consent_given boolean not null default false,
  consent_timestamp timestamptz,
  consent_ip_hash text,
  legal_disclaimer_version text not null,

  -- AI generation tracking
  diagnosis_status text not null default 'pending'
    check (diagnosis_status in ('pending', 'processing', 'completed', 'failed')),
  diagnosis_generated_at timestamptz,
  diagnosis_model text,
  diagnosis_error text
);

create index submissions_created_at_idx on public.submissions(created_at desc);
create index submissions_email_idx on public.submissions(email);
create index submissions_status_idx on public.submissions(diagnosis_status);

alter table public.submissions enable row level security;
-- No public policies; only service role can read/write.

-- ─── ORDERS ──────────────────────────────────────────────────
-- Stripe checkout sessions for paid services.
create table public.orders (
  id uuid primary key default uuid_generate_v4(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  submission_id uuid references public.submissions(id) on delete set null,

  product_id text not null,
  product_name text not null,
  amount_nok integer not null,
  currency text not null default 'NOK',

  customer_email text not null,
  customer_name text,

  -- Stripe
  stripe_session_id text unique,
  stripe_payment_intent_id text,
  stripe_customer_id text,

  status text not null default 'pending'
    check (status in ('pending', 'paid', 'fulfilled', 'failed', 'refunded', 'cancelled')),

  paid_at timestamptz,
  fulfilled_at timestamptz,

  -- Legal: every order records what the customer accepted
  legal_disclaimer_version text not null,
  deliverable_description text not null,

  metadata jsonb default '{}'::jsonb
);

create index orders_submission_id_idx on public.orders(submission_id);
create index orders_email_idx on public.orders(customer_email);
create index orders_stripe_session_idx on public.orders(stripe_session_id);
create index orders_status_idx on public.orders(status);

alter table public.orders enable row level security;

-- ─── EVENT LOG ───────────────────────────────────────────────
-- Auditable trail of webhooks and system events.
create table public.events (
  id uuid primary key default uuid_generate_v4(),
  created_at timestamptz not null default now(),
  event_type text not null,
  resource_type text,
  resource_id uuid,
  stripe_event_id text unique,
  payload jsonb,
  processed_at timestamptz
);

create index events_type_idx on public.events(event_type);
create index events_resource_idx on public.events(resource_type, resource_id);

alter table public.events enable row level security;

-- ─── UPDATED_AT TRIGGER ──────────────────────────────────────
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;

create trigger orders_set_updated_at
  before update on public.orders
  for each row execute function public.set_updated_at();

-- ─── STORAGE BUCKET (private) ────────────────────────────────
-- Decks bucket is private. Only service role can read/write.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'decks',
  'decks',
  false,
  26214400, -- 25 MB
  array[
    'application/pdf',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation'
  ]
)
on conflict (id) do update set
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

-- No public read policies on storage.objects for the decks bucket.
-- All access is via service role through server-side API routes only.
