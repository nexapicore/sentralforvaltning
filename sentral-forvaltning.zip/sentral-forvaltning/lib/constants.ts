// Client-safe constants (no secrets). Mirrors lib/products.ts for the UI.

export const LEGAL_DISCLAIMER_FULL = `Sentral Forvaltning AS yter strategisk forberedelse og forretningsmessig rådgivning. Tjenesten utgjør ikke investeringsråd, investeringsanalyse, verdipapirformidling, folkefinansiering, finansiell rådgivning, verdivurdering, eller tilbud om tegning eller kjøp av finansielle instrumenter. Alle vurderinger er basert på informasjon kunden selv oppgir og/eller materiale kunden laster opp.`;

export const LEGAL_DISCLAIMER_SHORT = `Sentral Forvaltning AS yter strategisk forberedelse og forretningsmessig rådgivning. Tjenesten utgjør ikke investeringsråd, verdipapirformidling eller tilbud om finansielle instrumenter.`;

export const CONSENT_TEXT = `Jeg forstår at dette er strategisk forberedelse basert på opplastet materiale og selvrapporterte svar, og ikke investeringsråd, verdivurdering, verdipapirformidling eller tilbud om finansielle instrumenter.`;

export const SECTORS = [
  'SaaS / Software',
  'Fintech',
  'Healthtech',
  'E-commerce',
  'Marketplace',
  'Hardware / Deeptech',
  'Consumer',
  'B2B Services',
  'Climate / Energy',
  'Annet'
] as const;

export const STAGES = [
  'Idé / Pre-produkt',
  'MVP / Beta',
  'Tidlig traksjon',
  'Vekstfase',
  'Skalering'
] as const;

export const PREPARING_FOR_OPTIONS = [
  'Første investorsamtaler',
  'Angel-runde',
  'Seed-runde',
  'Bridge-runde',
  'Strategisk investorprosess',
  'Ikke avklart ennå'
] as const;

export const MATERIALS_OPTIONS = [
  'Pitch deck',
  'Financial model',
  'Cap table',
  'Investor memo',
  'Data room',
  'Kundekontrakter / LOIs',
  'Ingenting strukturert ennå'
] as const;

export const UNCERTAINTY_OPTIONS = [
  'Er selskapet investorklart?',
  'Er decket godt nok?',
  'Er finansmodellen troverdig?',
  'Er kapitalbehovet riktig?',
  'Mangler vi viktige dokumenter?',
  'Hvordan bør historien fortelles?'
] as const;

// Public product catalog for UI display (price is reverified server-side at checkout)
export const PUBLIC_PRODUCTS = [
  {
    id: 'pitch-deck-review',
    category: 'MATERIAL REVIEW',
    name: 'Pitch Deck & Material Review',
    description:
      'Strukturert gjennomgang av pitch deck, investor memo og støttemateriale. Identifiserer mangler før kapitalprosess.',
    price_nok: 3500,
    featured: false
  },
  {
    id: 'financial-model-review',
    category: 'FINANCIAL REVIEW',
    name: 'Financial Model Review',
    description:
      'Gjennomgang av finansiell modell, antakelser, sensitivitet, runway, unit economics og kapitalbehov.',
    price_nok: 5000,
    featured: false
  },
  {
    id: 'full-readiness',
    category: 'FULL RAPPORT',
    name: 'Full Investor Readiness Assessment',
    description:
      'Strukturert advisory-gjennomgang på 9 forberedelseskategorier. 8–12-siders PDF med kategori-scorecard, risikoer og 30-dagers handlingsplan.',
    price_nok: 5000,
    featured: true
  },
  {
    id: 'readiness-package',
    category: '90-DAGERS PROGRAM',
    name: 'Investor Readiness Pakke',
    description:
      'Komplett 90-dagers forberedelsesplan. Full vurdering, pitch deck-gjennomgang, cap table og uke-for-uke handlingsplan med revurdering etter 90 dager.',
    price_nok: 15000,
    featured: true
  }
] as const;

export const SECONDARY_PRODUCTS = [
  { id: 'cap-table', name: 'Cap Table-gjennomgang', price_nok: 5000 },
  { id: 'capital-structure', name: 'Kapitalstruktur- og prisingsanalyse', price_nok: 7500 },
  { id: 'narrative-review', name: 'Investor-narrativ gjennomgang', price_nok: 3500 }
] as const;
