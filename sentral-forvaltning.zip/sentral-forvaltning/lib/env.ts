import { z } from 'zod';

// Validates server env on import. Throws if anything is missing.
const serverSchema = z.object({
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(1),
  STRIPE_SECRET_KEY: z.string().min(1),
  STRIPE_WEBHOOK_SECRET: z.string().min(1),
  ANTHROPIC_API_KEY: z.string().min(1),
  RESEND_API_KEY: z.string().min(1),
  INTERNAL_NOTIFICATION_EMAIL: z.string().email(),
  FROM_EMAIL: z.string().min(1),
  LEGAL_DISCLAIMER_VERSION: z.string().min(1)
});

const publicSchema = z.object({
  NEXT_PUBLIC_SUPABASE_URL: z.string().url(),
  NEXT_PUBLIC_SUPABASE_ANON_KEY: z.string().min(1),
  NEXT_PUBLIC_SITE_URL: z.string().url()
});

// Public env — safe to import client-side
export const publicEnv = publicSchema.parse({
  NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL,
  NEXT_PUBLIC_SUPABASE_ANON_KEY: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  NEXT_PUBLIC_SITE_URL: process.env.NEXT_PUBLIC_SITE_URL
});

// Server env — lazy-loaded, server-only
let _serverEnv: z.infer<typeof serverSchema> | null = null;
export function serverEnv() {
  if (typeof window !== 'undefined') {
    throw new Error('serverEnv() called from browser context — never expose secrets');
  }
  if (!_serverEnv) {
    _serverEnv = serverSchema.parse({
      SUPABASE_SERVICE_ROLE_KEY: process.env.SUPABASE_SERVICE_ROLE_KEY,
      STRIPE_SECRET_KEY: process.env.STRIPE_SECRET_KEY,
      STRIPE_WEBHOOK_SECRET: process.env.STRIPE_WEBHOOK_SECRET,
      ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY,
      RESEND_API_KEY: process.env.RESEND_API_KEY,
      INTERNAL_NOTIFICATION_EMAIL: process.env.INTERNAL_NOTIFICATION_EMAIL,
      FROM_EMAIL: process.env.FROM_EMAIL,
      LEGAL_DISCLAIMER_VERSION: process.env.LEGAL_DISCLAIMER_VERSION
    });
  }
  return _serverEnv;
}
