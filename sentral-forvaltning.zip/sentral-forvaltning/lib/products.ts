import { Product, ProductId } from '@/types';

// Canonical product catalog. Prices are NEVER read from client input —
// the client sends a product_id only, and the server resolves the price
// against this table before creating a Stripe Checkout Session.
export const PRODUCTS: Record<ProductId, Product> = {
  'pitch-deck-review': {
    id: 'pitch-deck-review',
    name: 'Pitch Deck & Material Review',
    price_nok: 3500,
    description:
      'Strukturert gjennomgang av pitch deck, investor memo og støttemateriale. Identifiserer mangler før kapitalprosess.',
    deliverable:
      'PDF-rapport med konkrete forbedringer av pitch deck og støttemateriale. Levert innen 24 timer.'
  },
  'financial-model-review': {
    id: 'financial-model-review',
    name: 'Financial Model Review',
    price_nok: 5000,
    description:
      'Gjennomgang av finansiell modell, antakelser, sensitivitet, runway, unit economics og kapitalbehov.',
    deliverable:
      'PDF-rapport med strukturert gjennomgang av finansiell modell og antakelser. Levert innen 24 timer.'
  },
  'full-readiness': {
    id: 'full-readiness',
    name: 'Full Investor Readiness Assessment',
    price_nok: 5000,
    description:
      'Strukturert advisory-gjennomgang på 9 forberedelseskategorier, levert som PDF-rapport med konkrete anbefalinger og 30-dagers handlingsplan.',
    deliverable:
      '8–12-siders PDF-rapport med kategori-scorecard, risikoer og 30-dagers handlingsplan. Levert innen 24 timer.'
  },
  'readiness-package': {
    id: 'readiness-package',
    name: 'Investor Readiness Pakke',
    price_nok: 15000,
    description:
      'Komplett 90-dagers forberedelsesplan. Full vurdering, pitch deck-gjennomgang, cap table og uke-for-uke handlingsplan med revurdering etter 90 dager.',
    deliverable:
      '90-dagers strukturert program med full readiness-vurdering, deck-gjennomgang, cap table-analyse, uke-for-uke plan og revurdering.'
  },
  'cap-table': {
    id: 'cap-table',
    name: 'Cap Table-gjennomgang',
    price_nok: 5000,
    description:
      'Strukturanalyse av eierskap, opsjoner og konvertibler. Utvanningsmodellering og opprydding før emisjon.',
    deliverable: 'PDF-rapport med cap table-analyse, utvanningsscenarier og strukturanbefalinger.'
  },
  'capital-structure': {
    id: 'capital-structure',
    name: 'Indikativ kapitalstruktur- og prisingsanalyse',
    price_nok: 7500,
    description:
      'Strategisk analyse av sannsynlig kapitalstruktur og indikative prisreferanser. Ikke formell verdivurdering.',
    deliverable:
      'PDF-rapport med indikative prisreferanser, sammenlignbare nordiske transaksjoner og utvanningsscenarier. Ikke en formell verdivurdering eller fairness opinion.'
  },
  'narrative-review': {
    id: 'narrative-review',
    name: 'Investor-narrativ gjennomgang',
    price_nok: 3500,
    description:
      'Strukturert gjennomgang av narrativ, deck og kommunikasjons-materiell. Identifiserer hvordan selskapet best kan posisjoneres for investorer.',
    deliverable: 'PDF-rapport med narrativ-gjennomgang og konkrete omskrivnings-forslag.'
  }
};

export function getProduct(id: string): Product | null {
  return (PRODUCTS as Record<string, Product>)[id] ?? null;
}
