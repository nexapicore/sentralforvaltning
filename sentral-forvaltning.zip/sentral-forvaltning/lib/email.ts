import { Resend } from 'resend';
import { serverEnv } from './env';
import { renderDiagnosisEmail } from '@/emails/DiagnosisEmail';
import { renderOrderConfirmationEmail } from '@/emails/OrderConfirmationEmail';
import { renderInternalOrderNotification } from '@/emails/InternalOrderNotification';
import { DiagnosisResult } from './diagnosis';

let _resend: Resend | null = null;
function resend() {
  if (!_resend) _resend = new Resend(serverEnv().RESEND_API_KEY);
  return _resend;
}

export async function sendDiagnosisEmail(args: {
  to: string;
  contact_name: string | null;
  company_name: string;
  diagnosis: DiagnosisResult;
  submission_id: string;
}) {
  const env = serverEnv();
  return resend().emails.send({
    from: env.FROM_EMAIL,
    to: args.to,
    subject: `Foreløpig readiness-diagnose for ${args.company_name}`,
    html: renderDiagnosisEmail(args)
  });
}

export async function sendOrderConfirmationEmail(args: {
  to: string;
  customer_name: string | null;
  product_name: string;
  amount_nok: number;
  order_id: string;
  deliverable_description: string;
}) {
  const env = serverEnv();
  return resend().emails.send({
    from: env.FROM_EMAIL,
    to: args.to,
    subject: `Bekreftelse: ${args.product_name}`,
    html: renderOrderConfirmationEmail(args)
  });
}

export async function sendInternalOrderNotification(args: {
  order_id: string;
  product_name: string;
  amount_nok: number;
  customer_email: string;
  customer_name: string | null;
  company_name: string | null;
  submission_id: string | null;
}) {
  const env = serverEnv();
  return resend().emails.send({
    from: env.FROM_EMAIL,
    to: env.INTERNAL_NOTIFICATION_EMAIL,
    subject: `[Ny ordre] ${args.product_name} — NOK ${args.amount_nok.toLocaleString('no-NO')}`,
    html: renderInternalOrderNotification(args)
  });
}
