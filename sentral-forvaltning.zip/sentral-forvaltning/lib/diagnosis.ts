import Anthropic from '@anthropic-ai/sdk';
import { serverEnv } from './env';
import { PRODUCTS } from './products';
import {
  ConfidenceClass,
  CoverageCategory,
  CoverageState,
  ProductId,
  SubmissionInput
} from '@/types';

// ─── HEURISTIC SCORING ───────────────────────────────────────
// Deterministic, audit-able. AI only enriches the prose.

export interface DiagnosisResult {
  score: number;
  badge: string;
  confidence_level: string;
  confidence_class: ConfidenceClass;
  strengths: string[];
  gaps: string[];
  coverage: CoverageCategory[];
  recommended_product_id: ProductId;
  recommended_product_name: string;
  recommended_product_price_nok: number;
  model_used: string;
}

interface ScoringInput {
  stage: string;
  has_materials: string[];
  preparing_for?: string;
  uncertainty?: string;
  has_deck: boolean;
}

function calculateScore(input: ScoringInput): number {
  let s = 42;
  if (input.has_deck) s += 6;

  if (input.stage.includes('Skalering')) s += 12;
  else if (input.stage.includes('Vekst')) s += 8;
  else if (input.stage.includes('traksjon')) s += 5;
  else if (input.stage.includes('MVP')) s += 2;
  else if (input.stage.includes('Idé')) s -= 4;

  const realMats = input.has_materials.filter(m => m !== 'Ingenting strukturert ennå');
  if (input.has_materials.includes('Ingenting strukturert ennå')) s -= 8;
  else s += realMats.length * 3;

  if (input.preparing_for?.includes('Seed') || input.preparing_for?.includes('Strategisk')) s += 4;
  else if (input.preparing_for === 'Ikke avklart ennå') s -= 2;

  return Math.max(15, Math.min(s, 86));
}

function classifyScore(score: number): string {
  if (score >= 85) return 'Avansert forberedelsesnivå';
  if (score >= 75) return 'Høy modenhet for kapitalforberedelse';
  if (score >= 60) return 'Sterke forberedelsessignaler';
  if (score >= 40) return 'Grunnleggende modenhet';
  return 'Tidlig forberedelse';
}

function calculateConfidence(input: ScoringInput): {
  level: string;
  class: ConfidenceClass;
  text: string;
} {
  let signals = 0;
  if (input.has_deck) signals += 2;
  const realMats = input.has_materials.filter(m => m !== 'Ingenting strukturert ennå').length;
  if (realMats >= 3) signals += 2;
  else if (realMats >= 1) signals += 1;
  if (input.preparing_for && input.preparing_for !== 'Ikke avklart ennå') signals += 1;
  if (input.uncertainty) signals += 1;

  if (signals >= 5) return { level: 'Høy', class: 'high', text: 'Høy — godt grunnlag' };
  if (signals >= 3)
    return { level: 'Middels', class: 'medium', text: 'Middels — flere felt kunne vært besvart' };
  return { level: 'Lav', class: 'low', text: 'Lav — begrenset grunnlag' };
}

function buildCoverage(input: ScoringInput): CoverageCategory[] {
  const has = (m: string) => input.has_materials.includes(m);
  const hasTraction =
    input.stage.includes('traksjon') ||
    input.stage.includes('Vekst') ||
    input.stage.includes('Skalering');

  return [
    { name: 'Team', state: 'covered' },
    { name: 'Marked', state: 'covered' },
    { name: 'Produkt', state: input.has_deck ? 'covered' : 'partial' },
    { name: 'Traksjon', state: hasTraction ? 'covered' : 'partial' },
    { name: 'Forretningsmodell', state: input.has_deck ? 'covered' : 'partial' },
    { name: 'Finansiell modell', state: has('Financial model') ? 'covered' : 'partial' },
    {
      name: 'Kapitalstrategi',
      state:
        input.preparing_for && input.preparing_for !== 'Ikke avklart ennå' ? 'partial' : 'missing'
    },
    { name: 'Risikoanalyse', state: 'missing' },
    { name: 'Cap table', state: has('Cap table') ? 'covered' : 'missing' },
    { name: 'Use of funds', state: 'partial' }
  ];
}

function recommendProduct(input: ScoringInput, score: number): ProductId {
  const u = input.uncertainty;

  if (u === 'Er decket godt nok?') return 'pitch-deck-review';
  if (u === 'Er finansmodellen troverdig?') return 'financial-model-review';
  if (u === 'Er kapitalbehovet riktig?') return 'capital-structure';
  if (u === 'Mangler vi viktige dokumenter?') return 'full-readiness';
  if (u === 'Hvordan bør historien fortelles?') return 'narrative-review';
  if (score < 60) return 'readiness-package';
  return 'full-readiness';
}

// ─── AI ENRICHMENT (Claude) ──────────────────────────────────
// Generates strengths/gaps as concrete prose. Returns deterministic
// fallbacks if the API fails — diagnosis must always complete.

const SYSTEM_PROMPT = `Du er en senior norsk readiness-rådgiver hos Sentral Forvaltning AS.

KRITISK: Du yter strategisk forberedelse — ikke investeringsråd, ikke verdivurdering, ikke verdipapirformidling. Bruk aldri ord som "investment opportunity", "VC Ready", "Investor Approved", "Institutional Grade", "investor matching", "allocation", "subscription". Aldri vurder selskapet som investeringsobjekt — kun som forberedelses-objekt.

Generer på norsk:
1. Tre konkrete identifiserte STYRKER basert på selskapets selv-rapporterte data (én setning hver, observerbart konkret, ikke smigrende)
2. Tre konkrete identifiserte MANGLER eller områder som bør prioriteres før kapitalprosess (én setning hver, direkte, ikke nedlatende)

Returner STRENGT JSON:
{"strengths":["...","...","..."],"gaps":["...","...","..."]}

Ingen forklaringer rundt. Bare JSON.`;

async function generateAIContent(
  input: ScoringInput & {
    company_name: string;
    sector: string;
    score: number;
  }
): Promise<{ strengths: string[]; gaps: string[]; model: string }> {
  const fallbackStrengths: string[] = [];
  if (input.has_deck) fallbackStrengths.push('Investormateriell tilgjengelig for vurdering');
  if (
    input.stage.includes('Vekst') ||
    input.stage.includes('traksjon') ||
    input.stage.includes('Skalering')
  )
    fallbackStrengths.push('Selvrapportert markedstraksjon');
  if (input.has_materials.includes('Financial model'))
    fallbackStrengths.push('Finansiell modell strukturert');
  if (input.has_materials.includes('Cap table')) fallbackStrengths.push('Cap table på plass');
  if (input.preparing_for && input.preparing_for !== 'Ikke avklart ennå')
    fallbackStrengths.push('Klar definisjon av kapitalprosess');
  while (fallbackStrengths.length < 3)
    fallbackStrengths.push('Forberedelses-signaler identifisert');

  const fallbackGaps: string[] = [];
  if (!input.has_deck) fallbackGaps.push('Pitch deck ikke lastet opp — narrativ kan ikke vurderes');
  if (!input.has_materials.includes('Financial model'))
    fallbackGaps.push('Finansiell modell mangler eller ikke strukturert');
  if (!input.has_materials.includes('Cap table')) fallbackGaps.push('Cap table ikke gjennomgått');
  if (input.preparing_for === 'Ikke avklart ennå')
    fallbackGaps.push('Kapitalprosess ikke definert');
  fallbackGaps.push('Use-of-funds og milestone-knytning bør struktureres');
  fallbackGaps.push('Risikooversikt for investor Q&A ikke vurdert');

  try {
    const client = new Anthropic({ apiKey: serverEnv().ANTHROPIC_API_KEY });
    const userMessage = `Selskap: ${input.company_name}
Sektor: ${input.sector}
Fase: ${input.stage}
Foreløpig score: ${input.score}/100
Forbereder seg på: ${input.preparing_for ?? 'ikke spesifisert'}
Største usikkerhet: ${input.uncertainty ?? 'ikke spesifisert'}
Eksisterende materiell: ${input.has_materials.join(', ') || 'ingen'}
Pitch deck lastet opp: ${input.has_deck ? 'ja' : 'nei'}`;

    const response = await client.messages.create({
      model: 'claude-sonnet-4-5',
      max_tokens: 800,
      system: SYSTEM_PROMPT,
      messages: [{ role: 'user', content: userMessage }]
    });

    const textBlock = response.content.find(b => b.type === 'text');
    if (!textBlock || textBlock.type !== 'text') throw new Error('No text block in response');

    // Strip any markdown fencing the model might add
    const cleaned = textBlock.text
      .replace(/^```json\s*/i, '')
      .replace(/^```\s*/, '')
      .replace(/```\s*$/, '')
      .trim();

    const parsed = JSON.parse(cleaned) as { strengths?: string[]; gaps?: string[] };

    const strengths = Array.isArray(parsed.strengths)
      ? parsed.strengths.slice(0, 3).map(String)
      : fallbackStrengths.slice(0, 3);
    const gaps = Array.isArray(parsed.gaps)
      ? parsed.gaps.slice(0, 3).map(String)
      : fallbackGaps.slice(0, 3);

    return {
      strengths: strengths.length === 3 ? strengths : fallbackStrengths.slice(0, 3),
      gaps: gaps.length === 3 ? gaps : fallbackGaps.slice(0, 3),
      model: response.model
    };
  } catch (err) {
    console.error('[diagnosis] AI enrichment failed, using fallback:', err);
    return {
      strengths: fallbackStrengths.slice(0, 3),
      gaps: fallbackGaps.slice(0, 3),
      model: 'fallback-heuristic'
    };
  }
}

// ─── MAIN ENTRY ──────────────────────────────────────────────
export async function generateDiagnosis(
  submission: SubmissionInput & { company_name: string }
): Promise<DiagnosisResult> {
  const scoringInput: ScoringInput = {
    stage: submission.stage,
    has_materials: submission.has_materials,
    preparing_for: submission.preparing_for,
    uncertainty: submission.uncertainty,
    has_deck: !!submission.deck_storage_path
  };

  const score = calculateScore(scoringInput);
  const badge = classifyScore(score);
  const confidence = calculateConfidence(scoringInput);
  const coverage = buildCoverage(scoringInput);
  const productId = recommendProduct(scoringInput, score);
  const product = PRODUCTS[productId];

  const ai = await generateAIContent({
    ...scoringInput,
    company_name: submission.company_name,
    sector: submission.sector,
    score
  });

  return {
    score,
    badge,
    confidence_level: confidence.level,
    confidence_class: confidence.class,
    strengths: ai.strengths,
    gaps: ai.gaps,
    coverage,
    recommended_product_id: productId,
    recommended_product_name: product.name,
    recommended_product_price_nok: product.price_nok,
    model_used: ai.model
  };
}
