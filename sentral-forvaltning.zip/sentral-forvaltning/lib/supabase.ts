import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { publicEnv, serverEnv } from './env';

// ─── ADMIN CLIENT (server-only) ─────────────────────────────
// Uses service role key. Bypasses RLS. NEVER import from client components.
let _admin: SupabaseClient | null = null;
export function supabaseAdmin(): SupabaseClient {
  if (typeof window !== 'undefined') {
    throw new Error('supabaseAdmin() called from browser — service role key must never be exposed');
  }
  if (!_admin) {
    _admin = createClient(
      publicEnv.NEXT_PUBLIC_SUPABASE_URL,
      serverEnv().SUPABASE_SERVICE_ROLE_KEY,
      { auth: { persistSession: false, autoRefreshToken: false } }
    );
  }
  return _admin;
}

// ─── PUBLIC CLIENT ──────────────────────────────────────────
// Anon key only. Safe in browser but currently we route everything
// through API routes for stricter validation and consent capture.
export function supabasePublic(): SupabaseClient {
  return createClient(
    publicEnv.NEXT_PUBLIC_SUPABASE_URL,
    publicEnv.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    { auth: { persistSession: false } }
  );
}

export const DECKS_BUCKET = 'decks';
