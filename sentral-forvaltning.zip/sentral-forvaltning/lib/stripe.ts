import Stripe from 'stripe';
import { serverEnv } from './env';

let _stripe: Stripe | null = null;

export function stripe(): Stripe {
  if (typeof window !== 'undefined') {
    throw new Error('stripe() called from browser');
  }
  if (!_stripe) {
    _stripe = new Stripe(serverEnv().STRIPE_SECRET_KEY, {
      apiVersion: '2024-10-28.acacia',
      typescript: true
    });
  }
  return _stripe;
}
