import { z } from 'zod';

// Norwegian-language stage values must match the form options exactly.
const ALLOWED_STAGES = [
  'Idé / Pre-produkt',
  'MVP / Beta',
  'Tidlig traksjon',
  'Vekstfase',
  'Skalering'
] as const;

const ALLOWED_SECTORS = [
  'SaaS / Software',
  'Fintech',
  'Healthtech',
  'E-commerce',
  'Marketplace',
  'Hardware / Deeptech',
  'Consumer',
  'B2B Services',
  'Climate / Energy',
  'Annet'
] as const;

const ALLOWED_PREPARING_FOR = [
  'Første investorsamtaler',
  'Angel-runde',
  'Seed-runde',
  'Bridge-runde',
  'Strategisk investorprosess',
  'Ikke avklart ennå'
] as const;

const ALLOWED_MATERIALS = [
  'Pitch deck',
  'Financial model',
  'Cap table',
  'Investor memo',
  'Data room',
  'Kundekontrakter / LOIs',
  'Ingenting strukturert ennå'
] as const;

const ALLOWED_UNCERTAINTY = [
  'Er selskapet investorklart?',
  'Er decket godt nok?',
  'Er finansmodellen troverdig?',
  'Er kapitalbehovet riktig?',
  'Mangler vi viktige dokumenter?',
  'Hvordan bør historien fortelles?'
] as const;

export const submissionSchema = z.object({
  company_name: z.string().trim().min(1, 'Selskapsnavn er påkrevd').max(200),
  sector: z.enum(ALLOWED_SECTORS),
  stage: z.enum(ALLOWED_STAGES),
  website: z.string().trim().max(300).optional().or(z.literal('')),
  email: z.string().trim().email('Gyldig e-postadresse er påkrevd').max(255),
  contact_name: z.string().trim().max(200).optional().or(z.literal('')),
  preparing_for: z.enum(ALLOWED_PREPARING_FOR).optional(),
  has_materials: z.array(z.enum(ALLOWED_MATERIALS)).max(10).default([]),
  uncertainty: z.enum(ALLOWED_UNCERTAINTY).optional(),
  deck_storage_path: z.string().trim().max(500).optional(),
  deck_filename: z.string().trim().max(255).optional(),
  deck_size_bytes: z.number().int().nonnegative().max(26214400).optional(),
  deck_mime_type: z.string().trim().max(100).optional(),
  consent_given: z.literal(true, {
    errorMap: () => ({ message: 'Du må bekrefte for å fortsette' })
  })
});

export type SubmissionPayload = z.infer<typeof submissionSchema>;

export const checkoutSchema = z.object({
  product_id: z.string().min(1).max(100),
  submission_id: z.string().uuid().optional(),
  customer_email: z.string().email().optional(),
  customer_name: z.string().trim().max(200).optional()
});

export type CheckoutPayload = z.infer<typeof checkoutSchema>;

export const ALLOWED_UPLOAD_MIME_TYPES = [
  'application/pdf',
  'application/vnd.ms-powerpoint',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation'
] as const;

export const MAX_UPLOAD_BYTES = 25 * 1024 * 1024; // 25 MB
