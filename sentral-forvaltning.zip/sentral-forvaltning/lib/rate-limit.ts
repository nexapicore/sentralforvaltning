import { NextRequest } from 'next/server';
import crypto from 'crypto';

// Simple per-IP token bucket. Resets on serverless cold start —
// good enough for abuse deterrence at the edge of a small consumer site.
// For higher scale, replace with Upstash Redis or Vercel KV.

interface Bucket {
  tokens: number;
  resetAt: number;
}

const buckets = new Map<string, Bucket>();

export function getClientIP(req: NextRequest): string {
  const xff = req.headers.get('x-forwarded-for');
  if (xff) return xff.split(',')[0]?.trim() ?? 'unknown';
  return req.headers.get('x-real-ip') ?? 'unknown';
}

export function hashIP(ip: string): string {
  // Hash before storing — never log raw IPs to the database.
  return crypto.createHash('sha256').update(ip).digest('hex').slice(0, 32);
}

export function checkRateLimit(
  identifier: string,
  opts: { max: number; windowMs: number }
): { allowed: boolean; remaining: number } {
  const now = Date.now();
  const existing = buckets.get(identifier);

  if (!existing || existing.resetAt < now) {
    buckets.set(identifier, { tokens: opts.max - 1, resetAt: now + opts.windowMs });
    return { allowed: true, remaining: opts.max - 1 };
  }

  if (existing.tokens <= 0) return { allowed: false, remaining: 0 };

  existing.tokens -= 1;
  return { allowed: true, remaining: existing.tokens };
}

// Periodic cleanup so the map doesn't grow forever
if (typeof setInterval !== 'undefined') {
  setInterval(() => {
    const now = Date.now();
    for (const [k, v] of buckets.entries()) {
      if (v.resetAt < now) buckets.delete(k);
    }
  }, 60_000).unref?.();
}
