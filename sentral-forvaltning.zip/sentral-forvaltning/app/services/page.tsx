import { ServiceCard } from '@/components/services/ServiceCard';
import { ServiceSmall } from '@/components/services/ServiceSmall';
import { PUBLIC_PRODUCTS, SECONDARY_PRODUCTS, LEGAL_DISCLAIMER_FULL } from '@/lib/constants';

export const metadata = {
  title: 'Tjenester — Sentral Forvaltning'
};

export default function ServicesPage() {
  return (
    <section className="screen">
      <div className="container">
        <div className="services-wrap">
          <div className="services-header">
            <div className="steps-eyebrow">Tjenester</div>
            <h2 className="services-title">Strukturerte leveranser fra Sentral Forvaltning</h2>
            <p className="services-sub">
              Faste priser knyttet til konkrete leveranser. Ingen suksess-honorar, ingen kapitalformidling.
            </p>
          </div>

          <div className="services-grid">
            {PUBLIC_PRODUCTS.map(p => (
              <ServiceCard
                key={p.id}
                id={p.id}
                category={p.category}
                name={p.name}
                description={p.description}
                price_nok={p.price_nok}
                featured={p.featured}
              />
            ))}
          </div>

          <div className="services-secondary">
            <h3 className="services-secondary-h">Spesialiserte gjennomganger</h3>
            <p className="services-secondary-sub">
              For modne selskaper med spesifikke forberedelses-behov.
            </p>
            <div className="services-secondary-grid">
              {SECONDARY_PRODUCTS.map(p => (
                <ServiceSmall key={p.id} id={p.id} name={p.name} price_nok={p.price_nok} />
              ))}
            </div>
          </div>

          <div className="trust-box" style={{ marginTop: 48 }}>
            <strong>Regulatorisk avklaring</strong>
            {LEGAL_DISCLAIMER_FULL}
          </div>
        </div>
      </div>
    </section>
  );
}
