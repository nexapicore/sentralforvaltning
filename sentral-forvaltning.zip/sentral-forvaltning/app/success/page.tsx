import Link from 'next/link';
import { notFound } from 'next/navigation';
import { supabaseAdmin } from '@/lib/supabase';

interface PageProps {
  searchParams: Promise<{ order?: string; session_id?: string }>;
}

export const dynamic = 'force-dynamic';

export const metadata = {
  title: 'Bestilling bekreftet — Sentral Forvaltning',
  robots: { index: false, follow: false }
};

export default async function SuccessPage({ searchParams }: PageProps) {
  const { order } = await searchParams;
  if (!order) notFound();

  const { data } = await supabaseAdmin()
    .from('orders')
    .select('product_name, amount_nok, status, customer_email, deliverable_description')
    .eq('id', order)
    .single();

  if (!data) notFound();

  const isPaid = data.status === 'paid' || data.status === 'fulfilled';

  return (
    <section className="screen">
      <div className="container-narrow">
        <div style={{ padding: '80px 0 60px', textAlign: 'center' }}>
          <div
            style={{
              width: 64,
              height: 64,
              borderRadius: '50%',
              background: 'var(--success-soft)',
              color: 'var(--success)',
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 32,
              marginBottom: 24
            }}
            aria-hidden
          >
            ✓
          </div>
          <h1 style={{ marginBottom: 16 }}>
            {isPaid ? 'Bestilling bekreftet' : 'Behandler betaling…'}
          </h1>
          <p
            style={{
              fontSize: 16,
              color: 'var(--muted)',
              maxWidth: 520,
              margin: '0 auto 32px',
              lineHeight: 1.6
            }}
          >
            {isPaid
              ? `Takk! Vi har mottatt din bestilling av ${data.product_name}. Bekreftelse er sendt til ${data.customer_email}. Leveranse innen 24 timer.`
              : 'Vi behandler betalingen. Du mottar bekreftelse på e-post straks transaksjonen er gjennomført.'}
          </p>

          <div
            style={{
              background: 'var(--card)',
              border: '1px solid var(--border-soft)',
              borderRadius: 'var(--radius)',
              padding: 28,
              textAlign: 'left',
              marginBottom: 32,
              boxShadow: 'var(--shadow-sm)'
            }}
          >
            <h3
              style={{
                fontFamily: 'Fraunces, serif',
                fontSize: 18,
                fontWeight: 500,
                marginBottom: 14,
                color: 'var(--ink)'
              }}
            >
              Hva skjer nå?
            </h3>
            <ol style={{ marginLeft: 20, fontSize: 14, color: 'var(--ink-soft)', lineHeight: 1.7 }}>
              <li style={{ marginBottom: 8 }}>
                Vi starter arbeidet basert på materialet du har lastet opp og dine svar.
              </li>
              <li style={{ marginBottom: 8 }}>
                Vi kontakter deg hvis vi trenger ytterligere informasjon.
              </li>
              <li>Du mottar leveransen på e-post innen 24 timer.</li>
            </ol>
          </div>

          <Link href="/" className="btn-secondary">
            Tilbake til forsiden
          </Link>

          <p
            style={{
              marginTop: 40,
              fontSize: 11,
              color: 'var(--faint)',
              maxWidth: 540,
              margin: '40px auto 0',
              lineHeight: 1.7
            }}
          >
            Sentral Forvaltning AS yter strategisk forberedelse og forretningsmessig rådgivning. Tjenesten utgjør ikke investeringsråd, verdivurdering eller tilbud om finansielle instrumenter. Ordre-ID: {order}
          </p>
        </div>
      </div>
    </section>
  );
}
