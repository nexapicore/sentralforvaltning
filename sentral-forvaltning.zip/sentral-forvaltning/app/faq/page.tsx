'use client';

import { useState } from 'react';

const FAQ = [
  {
    q: 'Er dette investeringsråd?',
    a: 'Nei. Sentral Forvaltning AS yter strategisk forberedelse til selskapet. Vi gir ikke investeringsråd, formidler ikke verdipapirer, og er ikke et regulert verdipapirforetak.'
  },
  {
    q: 'Hva skjer med pitch decket etter opplasting?',
    a: 'Opplastet materiale behandles strengt konfidensielt og brukes kun til å generere din diagnose og eventuelle bestilte leveranser. Det deles aldri med tredjeparter. Du kan be om sletting når som helst.'
  },
  {
    q: 'Henter dere kapital for oss?',
    a: 'Nei. Vi formidler ikke verdipapirer, gjennomfører ikke kapitalrunder, og kontakter ikke investorer på selskapets vegne. Vår tjeneste er strukturert forberedelse — selskapet selv kjører prosessen.'
  },
  {
    q: 'Er det en formell verdivurdering?',
    a: 'Nei. Kapitalstruktur- og prisingsanalyse er strategisk forberedelse. Det er ikke en formell verdivurdering, fairness opinion eller offer document.'
  },
  {
    q: 'Hvor presis er den foreløpige diagnosen?',
    a: 'Foreløpig diagnose er automatisert og basert på opplastet materiale og dine svar. Den er ment som indikasjon på hvor du bør fokusere. Full Readiness Assessment går vesentlig dypere.'
  },
  {
    q: 'Tar dere suksess-honorar?',
    a: 'Nei. Vi tar fast pris for definerte leveranser. Suksess-honorar knyttet til kapitalinnhenting er regulert virksomhet under verdipapirhandelloven som krever Finanstilsynet-konsesjon.'
  },
  {
    q: 'Hva koster Full Investor Readiness Assessment?',
    a: 'NOK 5 000 eks. MVA. Levert som PDF-rapport innen 24 timer. Inkluderer kategori-scorecard på 9 områder, identifiserte risikoer, anbefalt forbedringsplan og narrativ-gjennomgang.'
  }
];

export default function FAQPage() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section className="screen">
      <div className="container-narrow">
        <div className="faq-wrap">
          <div className="faq-header">
            <div className="steps-eyebrow">Vanlige spørsmål</div>
            <h2 className="services-title">Spørsmål vi ofte får</h2>
          </div>

          <div className="faq-list">
            {FAQ.map((item, i) => (
              <div key={i} className={`faq-item${open === i ? ' open' : ''}`}>
                <button
                  type="button"
                  className="faq-q"
                  onClick={() => setOpen(open === i ? null : i)}
                  aria-expanded={open === i}
                >
                  <span>{item.q}</span>
                  <span className="faq-icon" aria-hidden>+</span>
                </button>
                <div className="faq-a">
                  <div className="faq-a-inner">{item.a}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
