import { NextRequest, NextResponse } from 'next/server';
import { stripe } from '@/lib/stripe';
import { supabaseAdmin } from '@/lib/supabase';
import { getProduct } from '@/lib/products';
import { checkoutSchema } from '@/lib/validators';
import { publicEnv, serverEnv } from '@/lib/env';
import { checkRateLimit, getClientIP, hashIP } from '@/lib/rate-limit';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const ip = getClientIP(req);
  const rl = checkRateLimit(`checkout:${hashIP(ip)}`, { max: 20, windowMs: 60 * 60 * 1000 });
  if (!rl.allowed) {
    return NextResponse.json({ error: 'For mange forespørsler' }, { status: 429 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Ugyldig JSON' }, { status: 400 });
  }

  const parsed = checkoutSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: 'Valideringsfeil' }, { status: 400 });
  }
  const { product_id, submission_id, customer_email, customer_name } = parsed.data;

  // CRITICAL: never trust price from client. Resolve from server catalog.
  const product = getProduct(product_id);
  if (!product) {
    return NextResponse.json({ error: 'Ukjent produkt' }, { status: 400 });
  }

  const db = supabaseAdmin();
  const legalVersion = serverEnv().LEGAL_DISCLAIMER_VERSION;

  // If submission_id is provided, pull contact info from there
  let resolvedEmail = customer_email ?? '';
  let resolvedName = customer_name ?? null;
  if (submission_id) {
    const { data: sub } = await db
      .from('submissions')
      .select('email, contact_name')
      .eq('id', submission_id)
      .single();
    if (sub) {
      resolvedEmail = sub.email;
      resolvedName = sub.contact_name;
    }
  }

  // Create pending order row first — gives us an internal ID to pass to Stripe metadata
  const { data: order, error: orderError } = await db
    .from('orders')
    .insert({
      submission_id: submission_id || null,
      product_id: product.id,
      product_name: product.name,
      amount_nok: product.price_nok,
      currency: 'NOK',
      customer_email: resolvedEmail || 'pending@unknown',
      customer_name: resolvedName,
      status: 'pending',
      legal_disclaimer_version: legalVersion,
      deliverable_description: product.deliverable
    })
    .select('id')
    .single();

  if (orderError || !order) {
    console.error('[checkout] order insert error', orderError);
    return NextResponse.json({ error: 'Kunne ikke opprette ordre' }, { status: 500 });
  }

  const siteUrl = publicEnv.NEXT_PUBLIC_SITE_URL;

  try {
    const session = await stripe().checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: 'nok',
            unit_amount: product.price_nok * 100,
            product_data: {
              name: product.name,
              description: product.description
            }
          },
          quantity: 1
        }
      ],
      // Norwegian VAT must be added at checkout — adjust Tax settings in Stripe Dashboard
      customer_email: resolvedEmail || undefined,
      success_url: `${siteUrl}/success?order=${order.id}&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${siteUrl}/services?cancelled=1`,
      // CRITICAL legal framing — visible on the Stripe-hosted page
      consent_collection: { terms_of_service: 'none' },
      custom_text: {
        submit: {
          message:
            'Du bestiller en strukturert forberedelses-leveranse. Tjenesten utgjør ikke investeringsråd, verdipapirformidling eller tilbud om finansielle instrumenter.'
        }
      },
      metadata: {
        order_id: order.id,
        product_id: product.id,
        submission_id: submission_id ?? '',
        legal_disclaimer_version: legalVersion
      },
      payment_intent_data: {
        metadata: {
          order_id: order.id,
          product_id: product.id,
          legal_disclaimer_version: legalVersion
        },
        description: `${product.name} — ${product.deliverable}`
      }
    });

    await db
      .from('orders')
      .update({ stripe_session_id: session.id })
      .eq('id', order.id);

    if (!session.url) {
      return NextResponse.json({ error: 'Stripe returnerte ingen checkout-URL' }, { status: 500 });
    }

    return NextResponse.json({ url: session.url, order_id: order.id });
  } catch (err) {
    console.error('[checkout] stripe error', err);
    await db.from('orders').update({ status: 'failed' }).eq('id', order.id);
    return NextResponse.json({ error: 'Kunne ikke opprette checkout-sesjon' }, { status: 500 });
  }
}
