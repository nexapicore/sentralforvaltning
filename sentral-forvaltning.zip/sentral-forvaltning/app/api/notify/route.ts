import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { supabaseAdmin } from '@/lib/supabase';
import { sendInternalOrderNotification } from '@/lib/email';

export const runtime = 'nodejs';

// Internal endpoint to manually re-trigger an internal notification.
// Protected by a shared secret — never exposed to the client.

const schema = z.object({
  order_id: z.string().uuid(),
  secret: z.string()
});

export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: 'Validation error' }, { status: 400 });
  }

  // Reuse webhook secret as a simple shared secret for this admin endpoint.
  // For production, consider a separate INTERNAL_API_SECRET env var.
  if (parsed.data.secret !== process.env.STRIPE_WEBHOOK_SECRET) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const db = supabaseAdmin();
  const { data: order } = await db
    .from('orders')
    .select('id, product_name, amount_nok, customer_email, customer_name, submission_id')
    .eq('id', parsed.data.order_id)
    .single();

  if (!order) {
    return NextResponse.json({ error: 'Order not found' }, { status: 404 });
  }

  let companyName: string | null = null;
  if (order.submission_id) {
    const { data: sub } = await db
      .from('submissions')
      .select('company_name')
      .eq('id', order.submission_id)
      .single();
    companyName = sub?.company_name ?? null;
  }

  await sendInternalOrderNotification({
    order_id: order.id,
    product_name: order.product_name,
    amount_nok: order.amount_nok,
    customer_email: order.customer_email,
    customer_name: order.customer_name,
    company_name: companyName,
    submission_id: order.submission_id
  });

  return NextResponse.json({ sent: true });
}
