import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { supabaseAdmin, DECKS_BUCKET } from '@/lib/supabase';
import { checkRateLimit, getClientIP, hashIP } from '@/lib/rate-limit';
import { ALLOWED_UPLOAD_MIME_TYPES, MAX_UPLOAD_BYTES } from '@/lib/validators';

export const runtime = 'nodejs';
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  const ip = getClientIP(req);
  const rl = checkRateLimit(`upload:${hashIP(ip)}`, { max: 10, windowMs: 60 * 60 * 1000 });
  if (!rl.allowed) {
    return NextResponse.json({ error: 'For mange opplastinger. Prøv igjen senere.' }, { status: 429 });
  }

  let formData: FormData;
  try {
    formData = await req.formData();
  } catch {
    return NextResponse.json({ error: 'Ugyldig forespørsel' }, { status: 400 });
  }

  const file = formData.get('file');
  if (!(file instanceof File)) {
    return NextResponse.json({ error: 'Ingen fil mottatt' }, { status: 400 });
  }

  // ─── Server-side validation (never trust the client) ───
  if (file.size === 0) {
    return NextResponse.json({ error: 'Filen er tom' }, { status: 400 });
  }
  if (file.size > MAX_UPLOAD_BYTES) {
    return NextResponse.json({ error: 'Filen er for stor (maks 25 MB)' }, { status: 400 });
  }
  if (!ALLOWED_UPLOAD_MIME_TYPES.includes(file.type as (typeof ALLOWED_UPLOAD_MIME_TYPES)[number])) {
    return NextResponse.json({ error: 'Ugyldig filtype. Bruk PDF, PPT eller PPTX.' }, { status: 400 });
  }

  // Sanitize filename and generate a non-guessable storage path
  const originalName = file.name.replace(/[^\w.\-]/g, '_').slice(0, 200);
  const ext = originalName.split('.').pop()?.toLowerCase() ?? 'bin';
  const id = crypto.randomUUID();
  // Date-partitioned path for easy lifecycle management
  const datePrefix = new Date().toISOString().slice(0, 10);
  const storagePath = `${datePrefix}/${id}.${ext}`;

  const arrayBuffer = await file.arrayBuffer();

  const { error: uploadError } = await supabaseAdmin()
    .storage.from(DECKS_BUCKET)
    .upload(storagePath, arrayBuffer, {
      contentType: file.type,
      upsert: false,
      cacheControl: 'private, no-store'
    });

  if (uploadError) {
    console.error('[upload] storage error', uploadError);
    return NextResponse.json({ error: 'Kunne ikke lagre filen' }, { status: 500 });
  }

  return NextResponse.json({
    storage_path: storagePath,
    filename: originalName,
    size_bytes: file.size,
    mime_type: file.type
  });
}
