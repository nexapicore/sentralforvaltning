import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { supabaseAdmin } from '@/lib/supabase';
import { generateDiagnosis } from '@/lib/diagnosis';
import { sendDiagnosisEmail } from '@/lib/email';
import { checkRateLimit, getClientIP, hashIP } from '@/lib/rate-limit';

export const runtime = 'nodejs';
export const maxDuration = 60;

const requestSchema = z.object({
  submission_id: z.string().uuid()
});

export async function POST(req: NextRequest) {
  const ip = getClientIP(req);
  const rl = checkRateLimit(`diagnosis:${hashIP(ip)}`, { max: 10, windowMs: 60 * 60 * 1000 });
  if (!rl.allowed) {
    return NextResponse.json({ error: 'For mange forespørsler' }, { status: 429 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Ugyldig JSON' }, { status: 400 });
  }

  const parsed = requestSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: 'Manglende submission_id' }, { status: 400 });
  }

  const db = supabaseAdmin();

  // Atomically mark as processing so duplicate requests no-op.
  const { data: submission, error: fetchError } = await db
    .from('submissions')
    .select('*')
    .eq('id', parsed.data.submission_id)
    .single();

  if (fetchError || !submission) {
    return NextResponse.json({ error: 'Submission ikke funnet' }, { status: 404 });
  }

  // Idempotency — if already completed, return the existing diagnosis.
  if (submission.diagnosis_status === 'completed') {
    return NextResponse.json({
      score: submission.score,
      badge: submission.badge,
      confidence_level: submission.confidence_level,
      confidence_class: submission.confidence_class,
      strengths: submission.strengths,
      gaps: submission.gaps,
      coverage: submission.coverage,
      recommended_product_id: submission.recommended_product_id,
      recommended_product_name: submission.recommended_product_name,
      recommended_product_price_nok: submission.recommended_product_price_nok
    });
  }

  await db
    .from('submissions')
    .update({ diagnosis_status: 'processing' })
    .eq('id', submission.id);

  try {
    const diagnosis = await generateDiagnosis({
      company_name: submission.company_name,
      sector: submission.sector,
      stage: submission.stage,
      email: submission.email,
      preparing_for: submission.preparing_for ?? undefined,
      has_materials: (submission.has_materials as string[]) ?? [],
      uncertainty: submission.uncertainty ?? undefined,
      deck_storage_path: submission.deck_storage_path ?? undefined,
      consent_given: submission.consent_given
    });

    await db
      .from('submissions')
      .update({
        score: diagnosis.score,
        badge: diagnosis.badge,
        confidence_level: diagnosis.confidence_level,
        confidence_class: diagnosis.confidence_class,
        strengths: diagnosis.strengths,
        gaps: diagnosis.gaps,
        coverage: diagnosis.coverage,
        recommended_product_id: diagnosis.recommended_product_id,
        recommended_product_name: diagnosis.recommended_product_name,
        recommended_product_price_nok: diagnosis.recommended_product_price_nok,
        diagnosis_status: 'completed',
        diagnosis_generated_at: new Date().toISOString(),
        diagnosis_model: diagnosis.model_used
      })
      .eq('id', submission.id);

    // Fire-and-forget email — don't block the user's response on it.
    sendDiagnosisEmail({
      to: submission.email,
      contact_name: submission.contact_name,
      company_name: submission.company_name,
      diagnosis,
      submission_id: submission.id
    }).catch(err => console.error('[diagnosis] email send failed', err));

    return NextResponse.json({
      score: diagnosis.score,
      badge: diagnosis.badge,
      confidence_level: diagnosis.confidence_level,
      confidence_class: diagnosis.confidence_class,
      strengths: diagnosis.strengths,
      gaps: diagnosis.gaps,
      coverage: diagnosis.coverage,
      recommended_product_id: diagnosis.recommended_product_id,
      recommended_product_name: diagnosis.recommended_product_name,
      recommended_product_price_nok: diagnosis.recommended_product_price_nok
    });
  } catch (err) {
    console.error('[diagnosis] generation failed', err);
    await db
      .from('submissions')
      .update({
        diagnosis_status: 'failed',
        diagnosis_error: err instanceof Error ? err.message : 'unknown'
      })
      .eq('id', submission.id);
    return NextResponse.json({ error: 'Kunne ikke generere diagnose' }, { status: 500 });
  }
}
