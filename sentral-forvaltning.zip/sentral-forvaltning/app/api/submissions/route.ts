import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase';
import { submissionSchema } from '@/lib/validators';
import { checkRateLimit, getClientIP, hashIP } from '@/lib/rate-limit';
import { serverEnv } from '@/lib/env';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const ip = getClientIP(req);
  const ipHash = hashIP(ip);

  const rl = checkRateLimit(`submit:${ipHash}`, { max: 5, windowMs: 60 * 60 * 1000 });
  if (!rl.allowed) {
    return NextResponse.json(
      { error: 'For mange innsendinger fra denne IP-adressen. Prøv igjen senere.' },
      { status: 429 }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Ugyldig JSON' }, { status: 400 });
  }

  const parsed = submissionSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: 'Valideringsfeil', issues: parsed.error.flatten() },
      { status: 400 }
    );
  }
  const data = parsed.data;

  // Legal audit trail — exact moment consent was captured, version pinned
  const now = new Date().toISOString();
  const legalVersion = serverEnv().LEGAL_DISCLAIMER_VERSION;

  const { data: row, error } = await supabaseAdmin()
    .from('submissions')
    .insert({
      company_name: data.company_name,
      sector: data.sector,
      stage: data.stage,
      website: data.website || null,
      email: data.email,
      contact_name: data.contact_name || null,
      preparing_for: data.preparing_for || null,
      has_materials: data.has_materials,
      uncertainty: data.uncertainty || null,
      deck_storage_path: data.deck_storage_path || null,
      deck_filename: data.deck_filename || null,
      deck_size_bytes: data.deck_size_bytes || null,
      deck_mime_type: data.deck_mime_type || null,
      consent_given: data.consent_given,
      consent_timestamp: now,
      consent_ip_hash: ipHash,
      legal_disclaimer_version: legalVersion,
      diagnosis_status: 'pending'
    })
    .select('id')
    .single();

  if (error || !row) {
    console.error('[submissions] insert error', error);
    return NextResponse.json({ error: 'Kunne ikke lagre innsendingen' }, { status: 500 });
  }

  return NextResponse.json({ submission_id: row.id });
}
