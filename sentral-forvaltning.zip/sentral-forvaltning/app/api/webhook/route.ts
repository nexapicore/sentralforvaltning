import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';
import { stripe } from '@/lib/stripe';
import { supabaseAdmin } from '@/lib/supabase';
import { serverEnv } from '@/lib/env';
import {
  sendOrderConfirmationEmail,
  sendInternalOrderNotification
} from '@/lib/email';
import { getProduct } from '@/lib/products';

export const runtime = 'nodejs';

// Stripe sends raw body; Next.js gives us the raw bytes via req.text()
// on the App Router. We must NOT parse to JSON before verification.

export async function POST(req: NextRequest) {
  const signature = req.headers.get('stripe-signature');
  if (!signature) {
    return NextResponse.json({ error: 'Missing stripe-signature header' }, { status: 400 });
  }

  const rawBody = await req.text();
  const env = serverEnv();

  let event: Stripe.Event;
  try {
    event = stripe().webhooks.constructEvent(rawBody, signature, env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('[webhook] signature verification failed', err);
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
  }

  const db = supabaseAdmin();

  // Idempotency: log every event, skip if already processed
  const { data: existing } = await db
    .from('events')
    .select('id, processed_at')
    .eq('stripe_event_id', event.id)
    .maybeSingle();

  if (existing?.processed_at) {
    return NextResponse.json({ received: true, duplicate: true });
  }

  if (!existing) {
    await db.from('events').insert({
      event_type: event.type,
      stripe_event_id: event.id,
      payload: event as unknown as object
    });
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed':
        await handleCheckoutCompleted(event.data.object as Stripe.Checkout.Session);
        break;
      case 'checkout.session.expired':
        await handleCheckoutExpired(event.data.object as Stripe.Checkout.Session);
        break;
      case 'charge.refunded':
        await handleChargeRefunded(event.data.object as Stripe.Charge);
        break;
      default:
        // Log and ignore
        break;
    }

    await db
      .from('events')
      .update({ processed_at: new Date().toISOString() })
      .eq('stripe_event_id', event.id);

    return NextResponse.json({ received: true });
  } catch (err) {
    console.error('[webhook] handler error', err);
    return NextResponse.json({ error: 'Handler error' }, { status: 500 });
  }
}

async function handleCheckoutCompleted(session: Stripe.Checkout.Session) {
  const db = supabaseAdmin();
  const orderId = session.metadata?.order_id;
  if (!orderId) {
    console.error('[webhook] checkout.completed missing order_id metadata');
    return;
  }

  // Only mark paid if payment_status is paid (handles deferred payments)
  if (session.payment_status !== 'paid') {
    console.log(`[webhook] session ${session.id} payment_status=${session.payment_status}, skipping`);
    return;
  }

  const paymentIntentId =
    typeof session.payment_intent === 'string' ? session.payment_intent : session.payment_intent?.id;

  const { data: updated, error: updateError } = await db
    .from('orders')
    .update({
      status: 'paid',
      paid_at: new Date().toISOString(),
      stripe_payment_intent_id: paymentIntentId ?? null,
      stripe_customer_id: typeof session.customer === 'string' ? session.customer : null,
      customer_email: session.customer_details?.email ?? undefined,
      customer_name: session.customer_details?.name ?? undefined
    })
    .eq('id', orderId)
    .eq('status', 'pending') // only transition from pending
    .select('*')
    .single();

  if (updateError || !updated) {
    console.error('[webhook] order update failed (may already be paid)', updateError);
    return;
  }

  // Send confirmation to customer
  const product = getProduct(updated.product_id);
  const deliverable = product?.deliverable ?? updated.deliverable_description;

  await Promise.all([
    sendOrderConfirmationEmail({
      to: updated.customer_email,
      customer_name: updated.customer_name,
      product_name: updated.product_name,
      amount_nok: updated.amount_nok,
      order_id: updated.id,
      deliverable_description: deliverable
    }).catch(err => console.error('[webhook] customer email failed', err)),

    notifyInternal(updated.id)
  ]);
}

async function notifyInternal(orderId: string) {
  const db = supabaseAdmin();
  const { data: order } = await db
    .from('orders')
    .select('id, product_name, amount_nok, customer_email, customer_name, submission_id')
    .eq('id', orderId)
    .single();
  if (!order) return;

  let companyName: string | null = null;
  if (order.submission_id) {
    const { data: sub } = await db
      .from('submissions')
      .select('company_name')
      .eq('id', order.submission_id)
      .single();
    companyName = sub?.company_name ?? null;
  }

  await sendInternalOrderNotification({
    order_id: order.id,
    product_name: order.product_name,
    amount_nok: order.amount_nok,
    customer_email: order.customer_email,
    customer_name: order.customer_name,
    company_name: companyName,
    submission_id: order.submission_id
  }).catch(err => console.error('[webhook] internal notification failed', err));
}

async function handleCheckoutExpired(session: Stripe.Checkout.Session) {
  const db = supabaseAdmin();
  const orderId = session.metadata?.order_id;
  if (!orderId) return;
  await db.from('orders').update({ status: 'cancelled' }).eq('id', orderId).eq('status', 'pending');
}

async function handleChargeRefunded(charge: Stripe.Charge) {
  const db = supabaseAdmin();
  const pi = typeof charge.payment_intent === 'string' ? charge.payment_intent : null;
  if (!pi) return;
  await db
    .from('orders')
    .update({ status: 'refunded' })
    .eq('stripe_payment_intent_id', pi);
}
