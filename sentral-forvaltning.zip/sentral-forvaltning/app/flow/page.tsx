import { FlowController } from '@/components/flow/FlowController';

export const metadata = {
  title: 'Start readiness-sjekk — Sentral Forvaltning'
};

export default function FlowPage() {
  return (
    <section className="screen">
      <FlowController />
    </section>
  );
}
