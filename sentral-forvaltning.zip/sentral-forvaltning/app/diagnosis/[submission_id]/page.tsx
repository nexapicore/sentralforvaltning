import { notFound } from 'next/navigation';
import { supabaseAdmin } from '@/lib/supabase';
import { DiagnosisView } from '@/components/diagnosis/DiagnosisView';
import { Submission } from '@/types';

interface PageProps {
  params: Promise<{ submission_id: string }>;
}

export const dynamic = 'force-dynamic';

export default async function DiagnosisPage({ params }: PageProps) {
  const { submission_id } = await params;

  // Basic UUID format check before hitting the DB
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(submission_id)) {
    notFound();
  }

  const { data, error } = await supabaseAdmin()
    .from('submissions')
    .select('*')
    .eq('id', submission_id)
    .single();

  if (error || !data) notFound();

  const submission = data as unknown as Submission;
  return (
    <section className="screen">
      <DiagnosisView submission={submission} />
    </section>
  );
}

export const metadata = {
  title: 'Foreløpig diagnose — Sentral Forvaltning',
  robots: { index: false, follow: false }
};
