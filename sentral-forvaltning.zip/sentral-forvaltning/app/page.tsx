import { Hero } from '@/components/landing/Hero';
import { ThreeSteps } from '@/components/landing/ThreeSteps';
import { ExamplePreview } from '@/components/landing/ExamplePreview';
import { TrustBox } from '@/components/shared/TrustBox';
import { FinalCTA } from '@/components/landing/FinalCTA';

export default function HomePage() {
  return (
    <section className="screen">
      <div className="container-narrow">
        <Hero />
      </div>
      <div className="container">
        <ThreeSteps />
      </div>
      <div className="container-narrow">
        <ExamplePreview />
        <TrustBox />
        <FinalCTA />
      </div>
    </section>
  );
}
