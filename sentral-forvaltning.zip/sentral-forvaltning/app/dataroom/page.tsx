import Link from 'next/link';

const SECTIONS = [
  {
    title: 'Selskapsstruktur',
    status: 'required',
    desc: 'Grunnleggende selskaps-dokumentasjon.',
    items: [
      'Stiftelsesdokument og vedtekter',
      'Brønnøysund-utskrift',
      'Styreprotokoller (siste 24 mnd)',
      'Aksjonærregister og cap table'
    ]
  },
  {
    title: 'Finansielt',
    status: 'required',
    desc: 'Finansiell dokumentasjon for due diligence.',
    items: [
      'Regnskap (siste 2–3 år)',
      'Månedlig finansiell modell (24–36 mnd)',
      'Runway- og burn-analyse',
      'Use of funds (knyttet til milestones)'
    ]
  },
  {
    title: 'Juridisk',
    status: 'required',
    desc: 'Krever ofte advokat-bistand for utforming.',
    items: [
      'Aksjonæravtale',
      'Ansettelsesavtaler og IP-overdragelse',
      'Kundekontrakter (siste/aktive)',
      'GDPR- og personvernsdokumentasjon'
    ]
  },
  {
    title: 'Kommersielt',
    status: 'recommended',
    desc: 'Markedsdata og kunde-validering.',
    items: [
      'Markedsanalyse og TAM-metodikk',
      'Pipeline- og salgsdata',
      'Konkurranseanalyse',
      'Strategiske partneravtaler'
    ]
  }
];

export const metadata = {
  title: 'Data Room Readiness — Sentral Forvaltning'
};

export default function DataRoomPage() {
  return (
    <section className="screen">
      <div className="container-narrow">
        <div className="services-wrap">
          <div className="services-header">
            <div className="steps-eyebrow">Data Room Readiness</div>
            <h2 className="services-title">Forberedelse av materiell, ikke formidling</h2>
            <p className="services-sub">
              Sjekkliste for hva en seriøs investor typisk forventer ved due diligence. Selskapet eier alt materiell og all kommunikasjon med eventuelle investorer.
            </p>
          </div>

          <div
            style={{
              background: 'var(--card)',
              border: '1px solid var(--border-soft)',
              borderRadius: 'var(--radius)',
              padding: 32,
              boxShadow: 'var(--shadow-sm)'
            }}
          >
            <div style={{ display: 'grid', gap: 32 }}>
              {SECTIONS.map(s => (
                <div key={s.title}>
                  <h3
                    style={{
                      fontFamily: 'Fraunces, serif',
                      fontSize: 18,
                      fontWeight: 500,
                      color: 'var(--ink)',
                      marginBottom: 6
                    }}
                  >
                    {s.title}{' '}
                    <span
                      style={{
                        fontSize: 11,
                        color: s.status === 'required' ? 'var(--danger)' : 'var(--warning)',
                        background:
                          s.status === 'required' ? 'var(--danger-soft)' : 'var(--warning-soft)',
                        padding: '3px 8px',
                        borderRadius: 100,
                        marginLeft: 8,
                        verticalAlign: 'middle'
                      }}
                    >
                      {s.status === 'required' ? 'Påkrevd' : 'Anbefalt'}
                    </span>
                  </h3>
                  <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 14 }}>{s.desc}</p>
                  <ul style={{ listStyle: 'none', fontSize: 14, color: 'var(--ink-soft)' }}>
                    {s.items.map(i => (
                      <li key={i} style={{ padding: '4px 0 4px 20px', position: 'relative' }}>
                        <span style={{ position: 'absolute', left: 0, color: 'var(--accent)' }}>·</span>
                        {i}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            <div
              style={{
                marginTop: 32,
                paddingTop: 24,
                borderTop: '1px solid var(--border-soft)',
                fontSize: 12,
                color: 'var(--muted)',
                lineHeight: 1.6
              }}
            >
              <strong style={{ color: 'var(--ink)', display: 'block', marginBottom: 4 }}>Viktig:</strong>
              Sentral Forvaltning AS oppretter, drifter eller administrerer ikke selskapsspesifikke data rooms, formidler ikke materiell til investorer, og fasiliterer ikke verken kontakt eller kapitaltransaksjoner.
            </div>
          </div>

          <div style={{ textAlign: 'center', marginTop: 40 }}>
            <Link href="/flow" className="btn-primary">
              Start readiness-sjekk →
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
