export function renderInternalOrderNotification(args: {
  order_id: string;
  product_name: string;
  amount_nok: number;
  customer_email: string;
  customer_name: string | null;
  company_name: string | null;
  submission_id: string | null;
}): string {
  return `<!DOCTYPE html>
<html lang="no"><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#F7F5F0;font-family:-apple-system,Segoe UI,sans-serif;color:#1E2430;">
<table width="100%" cellpadding="0" cellspacing="0" style="padding:32px 20px;">
<tr><td align="center">
<table width="560" cellpadding="0" cellspacing="0" style="background:#FFF;border-radius:10px;border:1px solid #E4E0D8;">
<tr><td style="padding:28px;">
<div style="font-size:11px;color:#5D8A6A;letter-spacing:0.08em;text-transform:uppercase;font-weight:500;margin-bottom:8px;">Ny betalt ordre</div>
<h1 style="font-family:Georgia,serif;font-size:22px;font-weight:500;margin:0 0 16px;color:#1E2430;">${args.product_name}</h1>
<div style="font-family:Georgia,serif;font-size:28px;font-weight:500;color:#2F6F6D;margin-bottom:24px;">NOK ${args.amount_nok.toLocaleString('no-NO')}</div>

<table width="100%" cellpadding="0" cellspacing="0" style="background:#FCFBF8;border:1px solid #EFEBE3;border-radius:8px;">
<tr><td style="padding:18px 22px;">
${row('Kunde', args.customer_name ?? '—')}
${row('E-post', args.customer_email)}
${row('Selskap', args.company_name ?? '—')}
${row('Ordre-ID', args.order_id, true)}
${row('Submission', args.submission_id ?? '—', true)}
</td></tr>
</table>

<p style="font-size:13px;line-height:1.6;color:#6F7480;margin:20px 0 0;">Leveranse skal sendes innen 24 timer.</p>
</td></tr>
</table>
</td></tr></table>
</body></html>`;
}

function row(label: string, value: string, mono = false): string {
  return `<table width="100%" cellpadding="0" cellspacing="0" style="border-bottom:1px solid #EFEBE3;">
<tr>
<td style="padding:8px 0;font-size:12px;color:#6F7480;width:120px;">${label}</td>
<td style="padding:8px 0;font-size:13px;color:#1E2430;${mono ? 'font-family:monospace;' : ''}text-align:right;">${value}</td>
</tr></table>`;
}
