import { DiagnosisResult } from '@/lib/diagnosis';

const LEGAL_FOOTER = `Sentral Forvaltning AS yter strategisk forberedelse og forretningsmessig rådgivning. Tjenesten utgjør ikke investeringsråd, investeringsanalyse, verdipapirformidling, folkefinansiering, finansiell rådgivning, verdivurdering, eller tilbud om tegning eller kjøp av finansielle instrumenter. Alle vurderinger er basert på informasjon kunden selv oppgir og/eller materiale kunden laster opp.`;

export function renderDiagnosisEmail(args: {
  to: string;
  contact_name: string | null;
  company_name: string;
  diagnosis: DiagnosisResult;
  submission_id: string;
}): string {
  const { company_name, diagnosis, contact_name } = args;
  const greeting = contact_name ? `Hei ${contact_name},` : 'Hei,';

  const coverageHtml = diagnosis.coverage
    .map(c => {
      const color = c.state === 'covered' ? '#5D8A6A' : c.state === 'partial' ? '#C58A3A' : '#B45A4A';
      const bg = c.state === 'covered' ? '#E5EEE7' : c.state === 'partial' ? '#F6ECDB' : '#F2DFD9';
      return `<span style="display:inline-block;padding:5px 11px;font-size:12px;border-radius:100px;background:${bg};color:${color};margin:2px 3px;">${c.name}</span>`;
    })
    .join('');

  return `<!DOCTYPE html>
<html lang="no"><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#F7F5F0;font-family:-apple-system,Segoe UI,sans-serif;color:#1E2430;">
<table width="100%" cellpadding="0" cellspacing="0" style="padding:40px 20px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background:#FFF;border-radius:12px;overflow:hidden;border:1px solid #E4E0D8;">
<tr><td style="padding:32px 36px 24px;border-bottom:1px solid #EFEBE3;">
<div style="font-size:11px;color:#2F6F6D;letter-spacing:0.08em;text-transform:uppercase;font-weight:500;margin-bottom:8px;">Sentral Forvaltning</div>
<h1 style="font-family:Georgia,serif;font-size:24px;font-weight:500;margin:0;color:#1E2430;">Foreløpig readiness-diagnose</h1>
</td></tr>
<tr><td style="padding:32px 36px;">
<p style="margin:0 0 16px;font-size:15px;line-height:1.6;">${greeting}</p>
<p style="margin:0 0 24px;font-size:15px;line-height:1.6;color:#2E3543;">Her er foreløpig diagnose for <strong>${company_name}</strong>, basert på material og svar du ga oss.</p>

<table width="100%" cellpadding="0" cellspacing="0" style="background:#FCFBF8;border:1px solid #EFEBE3;border-radius:10px;margin-bottom:24px;">
<tr><td style="padding:24px;text-align:center;">
<div style="font-family:Georgia,serif;font-size:56px;font-weight:500;color:#2F6F6D;line-height:1;">${diagnosis.score}</div>
<div style="font-size:11px;color:#6F7480;letter-spacing:0.1em;text-transform:uppercase;margin-top:6px;">av 100 — foreløpig</div>
<div style="display:inline-block;margin-top:16px;background:#E6EFEE;color:#2F6F6D;font-size:13px;font-weight:500;padding:6px 14px;border-radius:100px;">${diagnosis.badge}</div>
<div style="margin-top:10px;font-size:11px;color:#6F7480;">Konfidens: ${diagnosis.confidence_level}</div>
</td></tr>
</table>

<h2 style="font-family:Georgia,serif;font-size:16px;font-weight:500;margin:24px 0 12px;color:#1E2430;">Identifiserte styrker</h2>
${diagnosis.strengths.map(s => `<div style="padding:8px 0 8px 16px;border-left:3px solid #5D8A6A;margin-bottom:6px;font-size:14px;line-height:1.5;">${s}</div>`).join('')}

<h2 style="font-family:Georgia,serif;font-size:16px;font-weight:500;margin:24px 0 12px;color:#1E2430;">Identifiserte mangler</h2>
${diagnosis.gaps.map(g => `<div style="padding:8px 0 8px 16px;border-left:3px solid #B45A4A;margin-bottom:6px;font-size:14px;line-height:1.5;">${g}</div>`).join('')}

<h2 style="font-family:Georgia,serif;font-size:16px;font-weight:500;margin:24px 0 12px;color:#1E2430;">Materialdekning</h2>
<div style="line-height:2;">${coverageHtml}</div>

<table width="100%" cellpadding="0" cellspacing="0" style="background:#FFF;border:2px solid #2F6F6D;border-radius:12px;margin:28px 0;">
<tr><td style="padding:24px;">
<div style="font-size:11px;color:#2F6F6D;font-weight:500;letter-spacing:0.06em;text-transform:uppercase;margin-bottom:10px;">Anbefalt neste steg</div>
<h3 style="font-family:Georgia,serif;font-size:20px;font-weight:500;margin:0 0 8px;color:#1E2430;">${diagnosis.recommended_product_name}</h3>
<div style="font-family:Georgia,serif;font-size:22px;font-weight:500;color:#2F6F6D;margin:14px 0 4px;">NOK ${diagnosis.recommended_product_price_nok.toLocaleString('no-NO')}</div>
<div style="font-size:11px;color:#6F7480;margin-bottom:18px;">eks. MVA · Levering innen 24 timer</div>
<a href="${process.env.NEXT_PUBLIC_SITE_URL}/services" style="display:inline-block;background:#2F6F6D;color:#FFF;padding:12px 24px;text-decoration:none;border-radius:8px;font-size:14px;font-weight:500;">Bestill →</a>
</td></tr>
</table>

<p style="font-size:13px;color:#6F7480;line-height:1.6;margin:24px 0;">Du finner full versjon av diagnosen og kan bestille direkte på sentralforvaltning.no. Har du spørsmål, svar på denne e-posten.</p>
</td></tr>

<tr><td style="padding:24px 36px;background:#FCFBF8;border-top:1px solid #EFEBE3;font-size:11px;color:#6F7480;line-height:1.7;">
<strong style="color:#1E2430;display:block;margin-bottom:6px;">Viktig avklaring</strong>
${LEGAL_FOOTER}
<div style="margin-top:14px;color:#A0A4AC;">Referanse: ${args.submission_id}<br>© 2026 Sentral Forvaltning AS · Oslo, Norge</div>
</td></tr>
</table>
</td></tr></table>
</body></html>`;
}
