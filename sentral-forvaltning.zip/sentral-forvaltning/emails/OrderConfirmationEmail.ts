const LEGAL_FOOTER = `Sentral Forvaltning AS yter strategisk forberedelse og forretningsmessig rådgivning. Tjenesten utgjør ikke investeringsråd, investeringsanalyse, verdipapirformidling, folkefinansiering, finansiell rådgivning, verdivurdering, eller tilbud om tegning eller kjøp av finansielle instrumenter.`;

export function renderOrderConfirmationEmail(args: {
  to: string;
  customer_name: string | null;
  product_name: string;
  amount_nok: number;
  order_id: string;
  deliverable_description: string;
}): string {
  const greeting = args.customer_name ? `Hei ${args.customer_name},` : 'Hei,';

  return `<!DOCTYPE html>
<html lang="no"><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#F7F5F0;font-family:-apple-system,Segoe UI,sans-serif;color:#1E2430;">
<table width="100%" cellpadding="0" cellspacing="0" style="padding:40px 20px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background:#FFF;border-radius:12px;overflow:hidden;border:1px solid #E4E0D8;">

<tr><td style="padding:32px 36px 24px;border-bottom:1px solid #EFEBE3;">
<div style="font-size:11px;color:#2F6F6D;letter-spacing:0.08em;text-transform:uppercase;font-weight:500;margin-bottom:8px;">Sentral Forvaltning</div>
<h1 style="font-family:Georgia,serif;font-size:24px;font-weight:500;margin:0;color:#1E2430;">Bestilling bekreftet</h1>
</td></tr>

<tr><td style="padding:32px 36px;">
<p style="margin:0 0 16px;font-size:15px;line-height:1.6;">${greeting}</p>
<p style="margin:0 0 24px;font-size:15px;line-height:1.6;color:#2E3543;">Takk for bestillingen. Vi har mottatt betaling og starter leveransen.</p>

<table width="100%" cellpadding="0" cellspacing="0" style="background:#FCFBF8;border:1px solid #EFEBE3;border-radius:10px;margin-bottom:24px;">
<tr><td style="padding:24px;">
<div style="font-size:11px;color:#6F7480;letter-spacing:0.04em;text-transform:uppercase;margin-bottom:6px;">Leveranse</div>
<h2 style="font-family:Georgia,serif;font-size:20px;font-weight:500;margin:0 0 14px;color:#1E2430;">${args.product_name}</h2>
<p style="margin:0 0 16px;font-size:14px;line-height:1.6;color:#6F7480;">${args.deliverable_description}</p>
<table width="100%" cellpadding="0" cellspacing="0" style="border-top:1px solid #EFEBE3;padding-top:14px;margin-top:14px;">
<tr>
<td style="padding-top:14px;font-size:13px;color:#6F7480;">Beløp betalt</td>
<td style="padding-top:14px;font-size:15px;color:#1E2430;font-weight:500;text-align:right;">NOK ${args.amount_nok.toLocaleString('no-NO')} eks. MVA</td>
</tr>
<tr>
<td style="font-size:13px;color:#6F7480;padding-top:6px;">Ordre-ID</td>
<td style="font-size:12px;color:#1E2430;text-align:right;font-family:monospace;padding-top:6px;">${args.order_id}</td>
</tr>
</table>
</td></tr>
</table>

<h3 style="font-family:Georgia,serif;font-size:16px;font-weight:500;margin:24px 0 12px;color:#1E2430;">Hva skjer nå?</h3>
<ol style="margin:0;padding-left:20px;font-size:14px;line-height:1.7;color:#2E3543;">
<li style="margin-bottom:8px;">Vi starter arbeidet basert på materialet du har lastet opp og dine svar.</li>
<li style="margin-bottom:8px;">Vi kontakter deg hvis vi trenger ytterligere informasjon.</li>
<li style="margin-bottom:8px;">Du mottar leveransen på e-post innen 24 timer.</li>
</ol>

<p style="margin:24px 0 0;font-size:14px;line-height:1.6;color:#2E3543;">Spørsmål? Bare svar på denne e-posten.</p>
</td></tr>

<tr><td style="padding:24px 36px;background:#FCFBF8;border-top:1px solid #EFEBE3;font-size:11px;color:#6F7480;line-height:1.7;">
<strong style="color:#1E2430;display:block;margin-bottom:6px;">Viktig avklaring</strong>
${LEGAL_FOOTER}
<div style="margin-top:14px;color:#A0A4AC;">© 2026 Sentral Forvaltning AS · Oslo, Norge</div>
</td></tr>

</table>
</td></tr></table>
</body></html>`;
}
